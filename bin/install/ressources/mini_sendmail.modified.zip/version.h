/* version.h - version define for mini_sendmail */

#ifndef _VERSION_H_
#define _VERSION_H_

#define VERSION "mini_sendmail/1.3.6 29jun2005"

#endif /* _VERSION_H_ */
