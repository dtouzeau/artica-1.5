<?php 
   //SSLBridge Config File generated on Nov, 21 2010 
   //Windows Domain Controller 
 define("LOCALHOST", "localhost");
   //Location SSLBridge needs write temp files 
 define("SYSTEMDIR", '/tmp');
 define("DEBUG", true);
 
?>
