<?php
	$have="AllmÃƒÂ¤nt";
	$want="Allmänt";

	$want=utf8_decode($want);

	print "What we have = " . $have . "<BR>";
	print "What we want = ". $want;

	$s=utf8_encode($have);

	$dec = utf8_decode($have);
	print  "<BR>TESTING==" . $s .  "<BR>";
	print "<br />Decode: $dec <br />";

	$s=utf8_encode($s);
	print  "<BR>Twice encoding TESTING==" . $s .  "<BR>";

	$b=utf8_encode(utf8_decode($have));
	print  "<BR>" . $b .  "<BR>";

	echo "<br />Stuff with $want:<br />";
	$x = utf8_encode($want);
	$h = utf8_decode($want);
	echo "Encode: $x - Decode: $h <br />";

	if(utf8_encode(utf8_decode($have)) != $have){
		print "<br />Does not Match";
	} else {
		print "<br />Match";
	}//end if(utf8_encode(utf8_decode($have)) != $have)
?>