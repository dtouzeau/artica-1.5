<?php ?>
<script type="text/javascript" src="./shakeObject.js"></script>
<script type="text/javascript">
	<?php
	sajax_show_javascript();
	?>
var activate = true;
var fail_attempt = 0;

function LoginUser(){
  //Turn off button...
	if(activate){
		document.getElementById('warning1').style.display = 'none';
		document.getElementById('warning2').style.display = 'none';
		document.getElementById('warning3').style.display = 'none';
		document.getElementById('warning4').style.display = 'none';
		document.getElementById('warning5').style.display = 'none';
		if(document.getElementById('username').value == '')
			document.getElementById('warning1').style.display = 'inline';
		else if(document.getElementById('password').value == '')
			document.getElementById('warning2').style.display = 'inline';
		else {
			activate = false;
			document.getElementById('loginButton').setAttribute('disabled','1');
			var btn=document.getElementById('waiting');
			btn.style.display='block';
			//btn.style.width='160px';
			do_user_login();
		}
	}
	return false;
}

function do_user_login_cb(x){
	//alert(x);
	if(x == "bad0") {
		//document.getElementById('username').value = '';
		document.getElementById('password').value = '';
		 btn=document.getElementById('waiting');
		btn.style.display='none';
		//btn.style.width='0px';
		shakeObject('shakeMe');
		fail_attempt++;
		if(fail_attempt < 3999) {
			document.getElementById('warning3').style.display = 'inline';
			document.getElementById('loginButton').removeAttribute('disabled');
		}else {
			//not sure what to do at the moment
		}
		//do some text here?
		activate = true;
	} else if (x=="bad1"){
		//document.getElementById('username').value = '';
		document.getElementById('password').value = '';
		 btn=document.getElementById('waiting');
		btn.style.display='none';
		//btn.style.width='0px';
		shakeObject('shakeMe');
		fail_attempt++;
		if(fail_attempt < 3999) {
			document.getElementById('warning4').style.display = 'inline';
			document.getElementById('loginButton').removeAttribute('disabled');
		}else {
			//not sure what to do at the moment
		}
		//do some text here?
		activate = true;
	} else if(x=="bad2"){
		//document.getElementById('username').value = '';
		document.getElementById('password').value = '';
		var btn=document.getElementById('waiting');
		btn.style.display='none';
		//btn.style.width='0px';
		shakeObject('shakeMe');
		fail_attempt++;
		if(fail_attempt < 3999) {
			document.getElementById('warning5').style.display = 'inline';
			document.getElementById('loginButton').removeAttribute('disabled');
		}else {
			//not sure what to do at the moment
		}
		//do some text here?
		activate = true;		
	}else {
		document.getElementById('warning1').style.display = 'none';
		document.getElementById('warning2').style.display = 'none';
		document.getElementById('warning3').style.display = 'none';
		document.getElementById('warning4').style.display = 'none';
		document.getElementById('warning5').style.display = 'none';
		//send the user over to the samba browser
		if(true)
			document.location.href=('./smb_browser.php');
		else
			document.location.href=('./smb_login.php?enc_param='+x);
	}
}

function do_user_login(){
	var usr = document.getElementById('username').value;
	var pwd = document.getElementById('password').value;
	//pwd = buildURL(pwd); //donno why it broke pmw
	//pwd.replace('+', '%pl%');
	x_user_login(usr, pwd, do_user_login_cb);
}

function setfocus() 
{
	//sorry for butchering this - pmw1302
	if(document.getElementById('username').value != ''){
<?php 
	//a litle php to set focus to password if we found a previous login value in a cookie
	//if($login != ""){
		//print "document.form1.password.focus();";
		print "document.getElementById('password').focus();";
	print "}else{";
		//print "document.form1.username.focus();";
		print "document.getElementById('username').focus();}";
	//}
?>
	return;
}

function init(){
	document.getElementById('warning1').style.display = 'none';
	document.getElementById('warning2').style.display = 'none';
	document.getElementById('warning3').style.display = 'none';
	document.getElementById('warning4').style.display = 'none';
	document.getElementById('warning5').style.display = 'none';
	setfocus();
}

//junk for string encoding
//a user had a + sign in their password.  This particular character breaks things
//no other characters could be found that broke this, but just to cover every
//possible case, we use this utf8 encoding to transmit the password over
function utf8(wide) {
  var c, s;
  var enc = "";
  var i = 0;
  while(i<wide.length) {
    c= wide.charCodeAt(i++);
    // handle UTF-16 surrogates
    if (c>=0xDC00 && c<0xE000) continue;
    if (c>=0xD800 && c<0xDC00) {
      if (i>=wide.length) continue;
      s= wide.charCodeAt(i++);
      if (s<0xDC00 || c>=0xDE00) continue;
      c= ((c-0xD800)<<10)+(s-0xDC00)+0x10000;
    }
    // output value
    if (c<0x80) enc += String.fromCharCode(c);
    else if (c<0x800) enc += String.fromCharCode(0xC0+(c>>6),0x80+(c&0x3F));
    else if (c<0x10000) enc += String.fromCharCode(0xE0+(c>>12),0x80+(c>>6&0x3F),0x80+(c&0x3F));
    else enc += String.fromCharCode(0xF0+(c>>18),0x80+(c>>12&0x3F),0x80+(c>>6&0x3F),0x80+(c&0x3F));
  }
  return enc;
}

var hexchars = "0123456789ABCDEF";

function toHex(n) {
  return hexchars.charAt(n>>4)+hexchars.charAt(n & 0xF);
}

var okURIchars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-";

function encodeURIComponentNew(s) {
  s = utf8(s);
  var c;
  var enc = "";
  for (var i= 0; i<s.length; i++) {
    if (okURIchars.indexOf(s.charAt(i))==-1)
      enc += "%"+toHex(s.charCodeAt(i));
    else
      enc += s.charAt(i);
  }
  return enc;
}

function buildURL(fld)
{
	if (fld == "") return false;
	var encodedField = "";
	var s = fld;
	if (typeof encodeURIComponent == "function")
	{
		// Use JavaScript built-in function
		// IE 5.5+ and Netscape 6+ and Mozilla
		encodedField = encodeURIComponent(s);
	}
	else 
	{
		// Need to mimic the JavaScript version
		// Netscape 4 and IE 4 and IE 5.0
		encodedField = encodeURIComponentNew(s);
	}

	//document.frm.fld.value=encodedField;
	//alert ("New encoding: " + encodeURIComponentNew(fld) +
	//	 "\n           escape(): " + escape(fld));


	return encodedField;
}
</script>