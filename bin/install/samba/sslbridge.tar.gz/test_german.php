<?php
	$command = "smbclient //RED/html -c 'dir' -D /1/Talböcker -I '192.168.1.20' -U 'patw%letmein' -W 'GOLD_MINE' -O 'TCP_NODEAY IPTOS_LOWDELA SO_KEEPALIVE SO_RCVBUF=8192 SO_SNDBUF=8192' -b 1200 -N | sort";
	echo "Command: $command <br /><div style='border:solid black 1px;'></div>";
	$result = exec($command);
	echo "Result: <pre style='background-color:gray;color:white;'>$result</pre>";
	echo '<br /><br />';
	$result2 = `$command`;
	echo "Result 2: <pre style='background-color:gray;color:white;'>$result2</pre>";
?>