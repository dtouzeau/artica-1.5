<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
	$done=false;

if(!@is_readable('./config.php')){
	header("location:./missingFile.php?f=config.php");
	exit;
} else if(!@is_readable('./webcrypt.php')){
	header("location:./missingFile.php?f=webcrypt.php");
	exit;
} else if(!@is_readable('./smbCommon.php')){
	header("location:./missingFile.php?f=smbCommon.php");
	exit;
} else if(!@is_readable('./corecfg.php')){
	header("location:./missingFile.php?f=smb_login_functions.php");
	exit;
}else{
	require_once('./corecfg.php');
	require_once('./config.php');
	require_once('./webcrypt.php');
	require_once('./smbCommon.php');
}
	$crypt = new EPI_CRYPT;
//	echo $_SESSION['username'];
	$holdMe = $_SESSION['username'];
	$holdMe2 = $_SESSION['password'];

	set_time_limit(0);

	if(isset($_SESSION['username'])){
		$dusername = rawurldecode($_SESSION['username']);
		$dpassword = rawurldecode($_SESSION['password']);
		$dusername = $crypt->WEB_decrypt($dusername);
		$dpassword = $crypt->WEB_decrypt($dpassword);
	} else {
		echo "There is an error with your authentication that prevents you from uploading files.  Please try again.  You may have to resubmit your credentials.";
		exit;
	}

	$_SESSION['username'] = $holdMe;
	$_SESSION['password'] = $holdMe2;
	session_write_close();
		
	if(DEMOMODE == 'true' && DEMOMODEU == 'false'){
		header('location: ./uploadFileX.php');
		exit;
	}
		
	ignore_user_abort();

	function format_doc_size($doc_size){
				 $doc_size = "". $doc_size;
				 $string_len =  strlen($doc_size);    
				 if($string_len > 3) {
					 //Going to chop and add the k
					 $doc_size = substr($doc_size,0,($string_len-3));
					 $doc_size = $doc_size . " k ";
				 }else {
					  if($string_len == 3) {
						$doc_size = substr($doc_size,0,1);    
						$doc_size = "~." . $doc_size . "k";
					  } else {
						$doc_size = "~.1k";
					 }
				 }
				 return $doc_size;
	} //end function format_doc_siz


	if(isset($_GET['enc_param'])){
		$enc_param = $_GET['enc_param'];
		$dec_param = $crypt->WEB_decrypt($enc_param);
		
		//Explicite LOAD for compile.. jk..
		parse_str($dec_param,$my_array);
        $l=$my_array['l'];
        $d=$my_array['d'];
        $wg=$my_array['wg'];


		$myLoc = $l;
		$myDir = $d;
		$workgroup = $wg;

		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"GetValues:($dec_param)");
			fclose($fp);
		}
/*
		$uploadDir = $source;
		if($myDir != '')
			$uploadDir .= $myDir;
*/
	}
	$test = false;
	if(isset($_POST['uploadDir'])){

		$myLoc = $_POST['Share'];
		$myDir = $_POST['Directory'];
		$workgroup = $_POST['wg'];

		//set up share
		$uid = uniqid(rand());
		$source = SYSTEMDIR.'/'.WORKINGDIR."/$uid";

		$cmd = makeNormDirectory(SYSTEMDIR.'/'.WORKINGDIR, $dusername, $dpassword);
		$cmd .= '\n'.makeNormDirectory(SYSTEMDIR.'/'.WORKINGDIR.'/'.$uid, $dusername, $dpassword);
		$cmd .= '\n'.makeMount($source, $myLoc, $workgroup, $dusername, $dpassword);	

		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"Results:($cmd)");
			fclose($fp);
		}

		$uploadDir = $source;
		if($myDir != '')
			$uploadDir .= $myDir;

		$test = fopen($source.'/smb_test_save.txt', "a");
		fclose($test);
	}
	$uploadFile = $uploadDir .'/'. $_FILES['userfile']['name'];
	if($test != false){
		$cmd = 'rm '.$source.'/smb_test_save.txt';
		$result = `$cmd`;
		if (@move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadFile)){
			echo 'File is valid, and was successfully uploaded.<br />';
			putenv("USER=$dusername%$dpassword");
			$cmd = "smbumount $source";
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"umount:($cmd)"."\n");
				fclose($fp);
			}
			$result = `$cmd`;
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"Result:($result)"."\n");
				fclose($fp);
			}
			$cmd = "rmdir $source";
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"Rmdir:($cmd)"."\n");
				fclose($fp);
			}
			$result = `$cmd`;
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"Result:($result)"."\n");
				fclose($fp);
			}
			$done=true;

			$sendSize = format_doc_size($_FILES['userfile']['size']);
			$sendName = $_FILES['userfile']['name'];
			$today = getDate();
			$wday = substr($today['weekday'],0,3);
			$month = substr($today['month'],0,3);
			$day = $today['mday'];
			$time = $today['hours'] . ':' .$today['minutes'] . ':' .$today['seconds'];
			$year = $today['year'];

			echo '
				<script type="text/javascript">

                    // NEW DHTML window refrence parent same way jk.. Mar,06
					//if(window.attachEvent){
					if(1==1){
						if(window.parent.rightSideC.firstChild != null){
							if(window.parent.rightSideC.firstChild.firstChild.id=="0textDiv"){
								window.parent.rightSide.removeChild(window.parent.rightSideC);
								window.parent.rightSideC = window.parent.document.createElement("div");
								window.parent.rightSide.appendChild(window.parent.rightSideC);							
							}
						}

						window.parent.changeStatusBar("File Upload Complete: '.$_FILES['userfile']['name'].'");
						if(window.parent.currentDirectory == window.parent.rightClkMenu.myDirectory){
							if(window.parent.currentWorkgroup == window.parent.rightClkMenu.myWorkgroup){
								if(window.parent.currentLocation == window.parent.rightClkMenu.myLocation){
window.parent.createRightItem("'.$sendName.'","'.$sendSize.'","'.$wday.'","'.$month.'","'.$day.'","'.$time.'","'.$year.'", "./ukn.gif");
								window.parent.rightClkMenu.crite = "pxi and ep two thousand five thru two thousand six";
								}
							}
						} 
					}else {

						if(self.opener.rightSideC.firstChild != null){
							if(self.opener.rightSideC.firstChild.firstChild.id=="0textDiv"){
								self.opener.rightSide.removeChild(self.opener.rightSideC);
								self.opener.rightSideC = document.createElement("div");
								self.opener.rightSide.appendChild(self.opener.rightSideC);							
							}
						}

						self.opener.changeStatusBar("File Upload Complete: '.$_FILES['userfile']['name'].'");
						if(self.opener.currentDirectory == self.opener.rightClkMenu.myDirectory){
							if(self.opener.currentWorkgroup == self.opener.rightClkMenu.myWorkgroup){
								if(self.opener.currentLocation == self.opener.rightClkMenu.myLocation){
self.opener.createRightItem("'.$sendName.'","'.$sendSize.'","'.$wday.'","'.$month.'","'.$day.'","'.$time.'","'.$year.'", "./ukn.gif");
								self.opener.rightClkMenu.crite = "pxi and ep two thousand five thru two thousand six";
								}
							}
						} 
					}
				</script>	
			';
		} else {
			//Not sure what to do if this occurs
			echo 'You do not have permission to upload a file to this directory.<br />';
			echo '
				<script type="text/javascript">
					if(window.attachEvent)
						window.parent.changeStatusBar("Upload Error: You do not have permission to upload a file to this directory");
					else 
						self.opener.changeStatusBar("Upload Error: You do not have permission to upload a file to this directory");
				</script>	
			';
			putenv("USER=$dusername%$dpassword");
			$cmd = "smbumount $source";
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"umount:($cmd)"."\n");
				fclose($fp);
			}
			$result = `$cmd`;
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"Result:($result)"."\n");
				fclose($fp);
			}
			$cmd = "rmdir $mount";
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"Rmdir:($cmd)"."\n");
				fclose($fp);
			}
			$result = `$cmd`;
			if(DEBUG == 'true'){
				$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
				fwrite ($fp,"Result:($result)"."\n");
				fclose($fp);
			}
			$done=true;
		}
	} else if(isset($_POST['uploadDir'])){
		echo 'You do not have permission to upload a file to this directory.<br />';
		echo '
			<script type="text/javascript">
					if(window.attachEvent)
						window.parent.changeStatusBar("Upload Error: You do not have permission to upload a file to this directory");
					else 
						self.opener.changeStatusBar("Upload Error: You do not have permission to upload a file to this directory");
			</script>	
		';
		putenv("USER=$dusername%$dpassword");
		$cmd = "smbumount $source";
		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"umount:($cmd)"."\n");
			fclose($fp);
		}
		$result = `$cmd`;
		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"Result:($result)"."\n");
			fclose($fp);
		}
		$cmd = "rmdir $mount";
		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"Rmdir:($cmd)"."\n");
			fclose($fp);
		}
		$result = `$cmd`;
		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"Result:($result)"."\n");
			fclose($fp);
		}
		$done=true;
	}
	//$_SESSION['username'] = $holdMe;
	//$_SESSION['password'] = $holdMe2;
	//echo $_SESSION['username'];
?>
<html>
<head><title></title>
<link rel="stylesheet" type="text/css" href="./simple.css" title="SambaBrowser" />
<script languge=JavaScript>

//used for jwin popup window
function close_window(){
   // alert('close fck');

	if(window.attachEvent){
	     //alert('ie');
		 window.parent.close_jwin();
	} else {
		self.close();		 

	}
}

function verifyMe(){
	if(document.getElementById("userfile").value == '')
		return false;
	else
		return true;
}

</script>
</head>
<body bgcolor="#ffffff">
<BR>
<?php 
	if($done){
		echo '</body></html>';
		exit;
	}
?>
	<form enctype="multipart/form-data" action="./uploadFile.php" method="post" onSubmit="return verifyMe()"> 
	     
		<?php
			if(DEMOMODEU == 'true')
				echo '<input type="hidden" name="MAX_FILE_SIZE" value="200000" />';
			else
				echo '<input type="hidden" name="MAX_FILE_SIZE" value="'.UPLOADLIMIT.'" />';
		?>
		<input type="hidden" name="Directory" value="<?php echo $myDir;?>" />
		<input type="hidden" name="wg" value="<?php echo $workgroup;?>" />
		<input type="hidden" name="Share" value="<?php echo $myLoc; ?>" />
		<input type="hidden" name="uploadDir" value="<?php echo $uploadDir; ?>" />
		<input type="hidden" name="username" value="<?php echo $dusername; ?>" />
		<input type="hidden" name="password" value="<?php echo $dpassword; ?>" />
		&nbsp;&nbsp;<B>Select a file for upload:</B> <BR>
		&nbsp;&nbsp;<input name="userfile" id = "userfile" type="file" size=80/>
         <BR><BR>
          <BR><BR>
          <BR><BR>
         <table width=100% border=0><tr><td align=right>

		 <input type="submit" value="  Upload File  " />&nbsp;

	 

		 </td></tr></table>
		 
	</form>	
</body>
</html>