<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>SSLBridge</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="./simple.css" rel="stylesheet" type="text/css">
<style type="text/css">
.printCfg{
	border:solid black 1px;
	background-color:#AAAAAA;
	font-size:10pt;
 
}
.warningText{
	color:red;
}
</style>


<style type="text/css">
<!--
.wrap0, .wrap1, .wrap2, .wrap3 {
  display:inline-table;
  /* \*/display:block;/**/
  }
.wrap0 {
  float:left;
  background:url(images/shadow.gif) right bottom no-repeat;
  }
.wrap1 {
  background:url(images/shadow180.gif) no-repeat;
  }
.wrap2 {
  background:url(images/corner_bl.gif) -16px 100% no-repeat;
  }
.wrap3 {
  padding:4px 6px 6px 4px;
  background:url(images/corner_tr.gif) 100% -16px no-repeat;
  }
.box {
	padding: 10px;
	background: #FFFFF5;
	border: 1px solid;
	border-color:#ccc #999 #999 #ccc;
}
.texta {
 font-size: 14px;
 font-style: bold;
 color: #042696;
 background-color: #E7FFFF;
 border: 1px solid #666666;
}

h3 code {font-style:normal;}

.standardText{
	font-size:12pt;
	font-family: <?php echo FONT_FACE; ?>;
}

.errorText {
	color:#880000;
}

.noticeText{
	color:#555555;
}
-->
</style>

<script type="text/javascript">
	function backButton(loc){
		document.getElementById("form2").action = loc;
		document.getElementById("form2").submit();
	}
</script>
</head>
<body class="branded">

<div id="masthead">Epiware SSLBridge</div> 
<div id="main">

	<div class="wrap0" style="width:500px;margin-left:auto;margin-right:auto;"> 
		<div class="wrap1"> 
			<div class="wrap2"> 
				<div class="wrap3"> 
						<div class="box" style="height:350px; ">  
						<h2>Create SSLBridge Configuration File - Step 2</h2>
						<?php	
							if(!isset($_POST['localhostName'])){
								echo '<p>This setup does not have all of the information needed to create a configuration file for your copy of SSLBridge.  Please click the "Previous" button to go to the start of the configuration.</p>';
								echo '<form id="form2" name="form2" action="setup1.php" method="post">
									<input type="hidden" id="f" name="f" value="'.$install.'" />';
								echo '<input type="submit" id="backBtn" value="<- Previous" />
								</form>';								
							} else {
								$install = htmlentities($_POST['f']);
								$localhostName = htmlentities($_POST['localhostName']);
								$tmpName = htmlentities($_POST['tmpName']);
							

								$configFile = "&lt;?php \n   //SSLBridge Config File generated on ". date('M, d Y', time())." \n   //Windows Domain Controller \n define(\"LOCALHOST\", \"$localhostName\");\n   //Location SSLBridge needs write temp files \n define(\"SYSTEMDIR\", '$tmpName'); \n?&gt;";

								echo '<p>SSLBridge will now attempt to create the <b>config.php</b> file...</p>';
								if(@is_writable('./')){
									$fileOpen = @fopen("./config.php",'w');
									@fwrite($fileOpen, html_entity_decode($configFile));
									@fclose($fileOpen);

									echo '<p>SSLBridge created the file <b>config.php</b> in the SSLBridge directory.  The file written follows.</p>';
								} else {
									echo '<p class="warningText">Warning: could not write to disk.&nbsp;&nbsp;&nbsp;<B>YOU MUST CREATE FILE "<Blink>config.php</blink>"</B></p>';
									echo '<p>SSLBridge is not able to create <b>config.php</b> on disk.  This is your configuration file.  Highlight all of the text below and in your browsers menu select Edit -> Copy.  Paste this information into a file named config.php that should be stored in SSLBridge\'s working directory (save in the install directory).</p>';
								}

								echo "<pre class='printCfg'>$configFile</pre>";


								if($install=='yes' || $install=="install"){
									echo '<form id="form2" name="form2" action="setup3.php" method="post">
										<input type="hidden" id="f" name="f" value="'.$install.'" />';
									echo '<input type="button" id="backBtn" onClick="javascript:backButton(\'setup1.php\')" value="<- Previous" />
									<input type="submit" value="      Next ->       " />
									</form>';
								} else {
									//display nothing
									//echo '<p>Thank you for creating the SSLBridge configuration file!</p>';

									echo '<form id="form2" name="form2" action="index.php" method="post">
										<input type="hidden" id="f" name="f" value="'.$install.'" />';
									//echo '<input type="button" id="backBtn" onClick="javascript:backButton(\'setup1.php\')" value="<- Previous" />
									 echo '
									<input type="submit" value="      HOME      " />
									</form>';
 


								}
							}
						?>

					</div> 
				</div> 
			</div> 
		</div> 
	</div>

</div>
</div>
</body>
</html>