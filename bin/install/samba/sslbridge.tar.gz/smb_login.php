<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
	require_once('./webcrypt.php');
	require_once('./config.php');
	if(!isset($_GET['enc_param'])){
		//if this value isn't set, then there is no point in going beyond this point
		//really should display an error message to the user
		header("location: index.php");

		exit;
	}
	$enc_param = $_GET['enc_param'];
	$crypt = new EPI_CRYPT;
	$dec_param = $crypt->WEB_decrypt($enc_param);

	parse_str($dec_param);

	//$username = $crypt->WEB_encrypt($username);
	//$password = $crypt->WEB_encrypt($password);
	
	//don't need the cookie for long, so why keep it around for long?
//print "$username";
//print "$password";
$u=$crypt->WEB_decrypt($username);
$p=$crypt->WEB_decrypt($password);

//print $u . "<BR>";
//print $p . "<BR>";


       $p=trim($p);
       $u=trim($u);

//echo "$u - $p<br />";
//exit;
$username=$crypt->WEB_encrypt($u);
$password=$crypt->WEB_encrypt($p);
//echo "$username - $password<br />";

       //$password=trim($password);
       //$username=trim($username);

	 	//define("EPI_COOKIE_EXPIRE_TIME",mktime()+60);

	if(USESESSION == 'true'){
		session_start();
		$_SESSION['username'] = $uname;
		$_SESSION['password'] = $pwd;		
	} else {
		define("CURRENT_DIR","/");
		if(DEBUG=='true' || NOTIMEOUT=='true')
			$set_time = false; //so we can debug it easier
		else
			$set_time = time()+30;
		setcookie("srvtm", $username,$set_time,CURRENT_DIR,"");
		setcookie("recversion", $password, $set_time,CURRENT_DIR,"");
	}
	header("location: smb_browser.php");
?>