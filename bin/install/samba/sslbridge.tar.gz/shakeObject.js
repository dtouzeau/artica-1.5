/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
var shakeIntervals = new Array();
var shakeOrigin = new Array();
var shakeDone = new Array();

function shakeObject(shake_elem_id){
	if(typeof(shakeDone[shake_elem_id])=="undefined")
		shakeDone[shake_elem_id] = true;
	if(shakeDone[shake_elem_id]){
		shakeDone[shake_elem_id]=false;

		var shake_elem = document.getElementById(shake_elem_id);
		var shake_step = 5;
		var shake_time = 50;
		var total_shake_time = 500;

		shakeOrigin[shake_elem_id] = parseInt(shake_elem.style.left);
		shakeIntervals[shake_elem_id] = setInterval("intervalShake('"+shake_elem_id+"', '"+shake_step+"','"+shake_time+"','"+total_shake_time+"')", shake_time);
	}
}

function intervalShake(shake_elem_id, shake_step, shake_time, total_shake_time){
	var shake_elem = document.getElementById(shake_elem_id);
	var current_pos = parseInt(document.getElementById(shake_elem_id).style.left);
	var newPos = shakeOrigin[shake_elem.id];

	shakeDone[shake_elem.id]*=1;
	shakeDone[shake_elem.id]+=(shake_time*1);
	if(shakeDone[shake_elem.id] >= total_shake_time) {
		shake_elem.style.left = shakeOrigin[shake_elem.id] + 'px';
		clearInterval(shakeIntervals[shake_elem.id]);
		shakeDone[shake_elem.id] = true;
	} else {
		if((current_pos*1) > (shakeOrigin[shake_elem.id]*1))
			newPos = (shakeOrigin[shake_elem.id]*1) - (shake_step*1);
		else 
			newPos = (shakeOrigin[shake_elem.id]*1) + (shake_step*1);

		shake_elem.style.left = newPos + 'px';
	}	
}