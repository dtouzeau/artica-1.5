<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
define('KEY','mbt6PzUwvDs');
class EPI_CRYPT {

  var $MD=1;
  function  EPI_CRYPT(){
     //-----------------------------------------------------------
     // Need to check to see whether mcrypt and mhash are installed.
     //If they are not installed I am going to use a less secure
     // encryption methind for the URLS however it will still be an
     // encryption method
     //-----------------------------------------------------------
     //------------------------------------------------------
     // OK how do I find out that that mcrypt is not working???
     // Cannot find out withou script dying. ie (cheking to see if
     // a mcrypt funciton works.  If not compiled php dies....
     // If the variable is defined in the config.inc I can use
     // MCRYPT and MHASH (3des) for encrypting the url string
     //------------------------------------------------------

      // GONE JK..
      //if(defined("MHASH_MCRYPT") && MHASH_MCRYPT == 1){
         //------------------------------------------------
         // If it IS NOT defined it will defualt to the MD5 standard
         // encryption
         //------------------------------------------------
     //    $this->MD = 0;
     // } else {
     //    $this->MD = 1;
    // }


  }

	/**
	*	get a variable from an encoded parameter string sent via the get statment
	*	@param	string	$name	name of parameter to get
	*	@return	string	value as listed in the parameter string or "" if not present
	*/
	function get_var_from_enc_param($name)
	{
                global $_GET;
		$answer = "";
		if(isset($_GET["enc_param"]))
		{
			$vars = array();
			$the_params = $this->WEB_decrypt($_GET["enc_param"]);

			parse_str($the_params,$vars);
			if(isset($vars[$name]))
			{
				$answer = $vars[$name];
			}
		}//end of if get param set
		return $answer;
	}//end of function get_var_from_enc_param

	/**
	*	get a variable from an encoded cookie string
	*	@param	string	$name	name of parameter to get
	*	@return	string	value as listed in the cookie string or "" if not present
	*/
	function get_var_from_enc_cookie($name)
	{
                global $_COOKIE;
		$answer = "";
		if(isset($_COOKIE[$name]))
		{
			$answer = $this->WEB_decrypt($_COOKIE[$name]);

		}//end of if get param set
		return $answer;
	}//end of function get_var_from_enc_cookie



	/**
	*	create a url with an encrypted parameter string
	*	@param	string	$page	base url
	*	@param	string	$param	parameter string
	*	@return	string	url with encoded parameters
	*/
	function create_url($page,$param)
	{
		if($param=="")
		{
			return $page;
		}
		else
		{
			if(substr($param,0,1)!="&")
			{
			$param = "&".$param;
			}

			$parameters = $this->WEB_encrypt($param);
			  // $parameters=urlencode($parameters);
			$url = $page."?enc_param=".$parameters;
			//	$url=htmlspecialchars($url);
			return $url;
		}
	}//end of function create_url






  function WEB_encrypt($pt) {
    if($this->MD == 1 ) {
        $final = $this->md_encrypt($pt,KEY);
     } else {
       //$realkey=mhash(HASH,KEY);
       //$iv=mcrypt_create_iv(mcrypt_get_block_size(CIPHER), MCRYPT_DEV_URANDOM);
       //$blob=mcrypt_ofb(CIPHER,$realkey,mhash(HASH,$pt).$pt,MCRYPT_ENCRYPT,$iv);
       /*
       * Note that mcrypt may add trailing nulls that must be stripped.
       */
       //$blob=substr($blob,0,strlen($pt)+mhash_get_block_size(HASH));
       //$final =  base64_encode($iv.$blob);
	      // Certai servers are breaking iwth thte URL...

    }


    $final=urlencode($final);
    return $final;
  }




/*
 * Decrypt previously encrypted plaintext message. Input is
 * expected to be base64 encoded, output is arbitrary string
 * or FALSE if decode failed.
 */
  function WEB_decrypt($blob) {

	 $blob=rawurldecode($blob);

    if($this->MD == 1 ) {
        // OK decrypt the MD5 has ass
        $final = $this->md_decrypt($blob,KEY);
     } else {
        //$realkey=mhash(HASH,KEY);
        //$rawblob=base64_decode($blob); /* binary blob */
        //$iv=substr($rawblob,0,mcrypt_get_block_size(CIPHER)); /* IV */
        //if (strlen($iv)<mcrypt_get_block_size(CIPHER))
        //  return FALSE;
        //$ct=substr($rawblob,mcrypt_get_block_size(CIPHER)); /* CipherText */
        //$unblob=mcrypt_ofb(CIPHER,$realkey,$ct,MCRYPT_DECRYPT,$iv);
        /*
        * mcrypt may add trailing nulls that must be stripped.
        */
        //$unblob=substr($unblob,0,strlen($ct));

        //$pt=substr($unblob,mhash_get_block_size(HASH));
        //$check=substr($unblob,0,mhash_get_block_size(HASH));

        //if ($check != mhash(HASH,$pt))
        //  $final = FALSE;
        //else
        //  $final =  $pt;
     }
     return $final;

  }






function key_do($txt,$encrypt_key)
{
  $encrypt_key = md5($encrypt_key);
  $ctr=0;
  $tmp = "";
  for ($i=0;$i<strlen($txt);$i++)
  {
     if ($ctr==strlen($encrypt_key)) $ctr=0;
     $tmp.= substr($txt,$i,1) ^ substr($encrypt_key,$ctr,1);
     $ctr++;
  }
  return $tmp;
}




function md_encrypt($txt,$key)
{
    srand((double)microtime()*1000000);
    $encrypt_key = md5(rand(0,32000));

   //$encrypt_key = md5($key);
   if(strlen($txt) < 5){
     $txt = $txt .  "     ";
   }

   $ctr=0;
   $tmp = "";
   for ($i=0;$i<strlen($txt);$i++)
   {
      if ($ctr==strlen($encrypt_key)) $ctr=0;
      $tmp.= substr($encrypt_key,$ctr,1) .
      (substr($txt,$i,1) ^ substr($encrypt_key,$ctr,1));
      $ctr++;
   }
   return base64_encode($this->key_do($tmp,$key));
}



function md_decrypt($txt,$key)
{
   $txt = $this->key_do(base64_decode($txt),$key);
   $tmp = "";
   for ($i=0;$i<strlen($txt);$i++)
   {
      $md5 = substr($txt,$i,1);
      $i++;
      $tmp.= (substr($txt,$i,1) ^ $md5);
   }
   $tmp = chop($tmp);
   return $tmp;

}





}

?>