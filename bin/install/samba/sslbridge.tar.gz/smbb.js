/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham and James Kern.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
	
	//LEAVE THESE ALONE - THESE ARE REFUGES FROM CONFIG.JS..............
	var useRightIcons = true;
	var debugMode = false;
	var useSession = true;

	//DEMO
	var firstLoad = false;
	var firstFolder = false;
	var secondFolder = false;

	var stepOne = false;
	var stepTwo = false;
	var stepThree = false;
	var stepFour = false;
	var stepFive = false;
	var stepSix = false;
	var stepSeven = false;

	var msgWorkgroup = null;
	var msgServer = null;
	var msgShare = null;
	var msgDir = null;
	var msgFolder = null;
	var msgFile = null;

	//The first thing we need to do is get the cookie information
	var username ='';
	var password ='';

	//Since cookies are important to this page, we'll make sure that cookies are enabled
	var cookieEnabled=(navigator.cookieEnabled)? true : false;
	//if not IE4+ nor NS6+
	if (typeof navigator.cookieEnabled=="undefined" && !cookieEnabled){ 
		document.cookie="testcookie"
		cookieEnabled=(document.cookie.indexOf("testcookie")!=-1)? true : false;
	}

	if (!cookieEnabled)	{
		alert('Your browser does not support cookies.  Please enable cookies on your browser or use a browser that supports cookies.');
		window.location.href="./index.php";		
	} else if(!useSession){ //need to make it so that cookies can be used - in case server load switches screw up sessions
		var split = document.cookie.split(';');
		var stop1 = split[0].split('=');
		var quit = 'no';
		var moveThrough = 0;
		var maxMoveThrough = split.length;
		var holdMeHere = '';
		while(quit == 'no'){
			if(split[moveThrough].indexOf('srvtm')>=0){
				holdMeHere = split[moveThrough].split('=');
				username = holdMeHere[1];
			}
			if(split[moveThrough].indexOf('recversion')>=0){
				holdMeHere = split[moveThrough].split('=');
				password = holdMeHere[1];
			}
			moveThrough++;
			if((password != '' && username != '')||(moveThrough == maxMoveThrough)){
				quit = 'yes';
			}
		}
		if((username == '' || typeof(username)=='undefined')||(password == '' || typeof(password)=='undefined')) {//just catches if the user hits refresh - the cookie should be dead by now
			alert('Please return to the login page and resubmit your credentials.');
			window.location.href="./index.php";
		}
/*
		if(stop1[0] == 'srvtm')
			username = stop1[1];
		else if(stop1[0] == 'recversion')
			password = stop1[1];
		var stop2 = split[1].split('=');	//will die here if no cookie enabled
		if(stop2[0] == 'srvtm')
			username = stop1[1];
		else if(stop2[0] == 'recversion')
		password = stop2[1];

		if(username == '' || typeof(username)=='undefined') //just catches if the user hits refresh
			alert('Please return to the login page to resubmit your credentials.');
		alert(username + ' - ' + password);
*/
	} else {
		//shouldn't need to do anything
	}
	
	//upon request
	//If you set this to false, the right-side icons will be absent from the files.
	//If set to true, the right-side icons will appear.
	//var useRightIcons = true;
	var ieorff = 'IE'; //default
	var ie7 = false; //I can't believe I have to do such a blatent hack...
	                 //I hate JScript...
	//OS detection
	var OSName="Unknown OS";
	var BrowserName = "Unknown Browser";
	var Safari = false;
	if (navigator.appVersion.indexOf("Win")!=-1) OSName="Windows";
	if (navigator.appVersion.indexOf("Mac")!=-1) OSName="MacOS";
	if (navigator.appVersion.indexOf("X11")!=-1) OSName="UNIX";
	if (navigator.appVersion.indexOf("Linux")!=-1) OSName="Linux";
	
	if(navigator.userAgent.indexOf("Safari")!=-1) BrowserName="Safari";
	if(navigator.userAgent.indexOf("Safari")!=-1) Safari = true;

	if(navigator.userAgent.indexOf("MSIE 7.")!=-1) ie7 = true;

	//disables the right-click - don't feel like wasting a listener on it
	//JK moving up higher in in code execution???? ..stange problems.

  //right click off jk.  
//	window.oncontextmenu=function (){return false; } ;
	

	//Needed for the JavaScript pop-up window
 	//var jwin;
	//Here is some JWin junk - not sure what I need it for yet
	function close_jwin(){
	    jwin.hideWin();	
	}

	function checker(){
	    //alert('gotit');	
	}


	var smbCommand = ''; //Tells us whether we are expecting data for the right-hand side or not/what Samba command
						 //we are using
	var whatToExpect = 'workgroups'; //What we are returning with our call to handleRequest

	var whereTo = ''; //Declairs where the folders should be placed on the left-hand side
	var blockLoading = false; //Sometimes a load will take a long, long time.  This way we can assure that the 
							  //content on the right-hand side is going to be displayed correctly.
	var blockAreaClick = false;

	var rightSide = ''; //Right-hand side of browser
	var leftSide = ''; //Left-hand side of browser
	var mover = ''; //the drag to resize
	var moveBar = ''; //the div that we actually drag
	var dragMe = '';
	var dragContent = '';
	var loadingDiv = '';
	var rightClkMenu = '';
	var rightClkMenu2 = '';
	var statusBar = '';
	var rightSideC = '';

	var leftWidth = 240;

	var doFilesOnly = false; //When drawing folders and files, signles if we should draw folders
	var viewingFolder = ''; //Holds the ID of the most recent clicked item on the left-hand side

	var doingDrag = false; //When we are dragging, this is set to true
	var dragTextValue = null;

	var selectedItems = new Array(); //holds a list of right-hand item element numbers (since each is numbered);
	var selectedFolder = '';
	var currentFolder = '';
	var prevFolder = '';
	var shiftPivot = '';
	var shiftPrevious = '';

	//for copy-paste
	var copyLocation  = '';
	var copyWorkgroup = '';
	var copyDirectory  = '';
	var copyItems = new Array();
	var lastWorkgroup = '';

	//current holds the values of the right-side that is open.  
	var currentLocation = '';
	var currentWorkgroup = '';
	var currentDirectory = '';

	var inQueue = 0;
	var errorOff = false;

	var noFiles = false;

	var pageLimit = 0; //when = 0, disabled
	var pages = '';
	var currentPage = 0;

	var becauseISaySo = false;

	scoot_speed = 5;
	var fade_speed = 15;

	var waitingDiv = null;
	var waitingText = null;
	var messageDiv = null;
	var messageText = null;

	var zipMade = false;
	var zipInterval = null;
	var zipEnc = null;
	var zipList = null;
	var zipTime = null;

	var templateRight =  null;

	var rightLocation = null;
	var rightDirectory = null;
	var leftObjType = new Array();
	var leftLocation = new Array();
	var leftDirectory = new Array();
	var leftWorkgroup = new Array();

	var rightTemplate = null;

	//function do_handleRequest()
	//Sajax 
	//Calls the function needed to start the Sajaxed PHP function handleRequest
	function do_handleRequest(useCred, loc, myVar, wg, direc, opt){
		//If, for some reason, we arn't allowed to change the content of the right-hand side, why should we even
		//make the call?
		if(blockLoading)
			return;
		blockLoading = true;
		if (wg != '')
			lastWorkgroup = wg;
		
		//alert("Location: "+loc+" Work Group: "+wg+" Directory: "+direc);
		x_handleRequest(useCred, username, password, loc, myVar, wg, direc, opt, do_handleRequest_cb);
	}

	//function do_handleRequest_cb()
	//Sajax callback
	//This will take the arrays passed back and, depending on the value of whatToExpect, will populate the correct
	//list (on left, right, or both sides)
	function do_handleRequest_cb(z){
		//The function is split into two parts.  Part 1 triggers if smbCommand is 1.  Part 2 triggers if smbCommand is 2.
		//There are only 2 Samba commands that are used for this application.  One returns workgroups, servers and shares.
		//The other returns folders, subfolders and files.
		 //alert(z);

		 //Added May jk.. This is a complete HACK to make comiled code work
		 // Not sure why but +: is tagged on to begging of string...
         var temp= z.substr(1,2 );
		 if(temp=='+:'){
              z=z.substr(3, z.length);
         }
		 // END of compile hack

		if(debugMode)
			alert(z);
		var statusCount = 0;
		var statusCount2 = 0;

		//Special Error Cases
		if(z == 'gotoMain'){
			alert("Your authentication has expired.  Please return to the login screen and revalidate your login.");
			window.location.href='./index.php';
		} else if (z=='c') {
			alert("Cpyrt PXI & Epwr MMV to MMVI");
		}

		eval("window.passed = " + z);	
		if(window.passed['error'] == 'error'){ //Error catcher
			postError(window.passed['msg']);
		} else if(smbCommand == 1){ //If we are expecting workgroups, servers, or shares
			pageLimit = window.passed['paged'];
			var forIcon = document.getElementById(parseInt(whereTo)+'iconIcon');
			//Shares are in window.passed[0]
			//Servers are in window.passed[1]
			//Workgroups are in window.passed[2]
			var itemNumber = parseInt(whereTo);
			var itemPlus = document.getElementById(itemNumber + "minusBox");
			
			if(whatToExpect == 'workgroups'){ //should only happen on init
				loopMe = window.passed[2].length;
				if(loopMe <= 1)
					itemPlus.style.visibility = "hidden";
				for(wg_it = 1; wg_it < loopMe; wg_it++){
					statusCount++;
					//alert(window.passed[2][wg_it]['type']);
					createLeftItem('left', window.passed[2][wg_it]['name'], 'workgroup', window.passed[2][wg_it]['name'], window.passed[2][wg_it]['type'], '', 'wgIcon');
					//alert(window.passed[2][wg_it]['name'] + ' - ' + window.passed[2][wg_it]['type']);
				}

				msgWorkgroup = window.passed[2][1]['name'];

				changeStatusBar("Loaded Workgroups: " + statusCount+ " total");
				//When you pass pmw_blank_hack in as the name of a left item, you create literally a div with no display
				//property (none).  This is there in case you have a folder without ...  ya know, I don't know if this
				//is needed.  Let me get back to you.
				//Yea it is, for workgroups and servers, although those workgroups and servers would be useless.
				//Anyway, enjoy the show...
				createLeftItem(whereTo, 'pmw_blank_hack', '', '', '', '', '');
				setToWindow();
				if(ieorff!="IE")
					fade(document.getElementById(whereTo), 100, 0, 100);

			} else if(whatToExpect == 'servers'){
				if(whereTo != '')
					forIcon.src='./images/network.gif';
				loopMe = window.passed[1].length;
				if(loopMe <= 1)
					itemPlus.style.visibility = "hidden";
				if(loopMe <= 1){ //The network isn't configured correctly, however at this point we know the name of
								 //one server on the network - the master we just used.  So we will display that
								 //one and continue on our way  --  This shouldn't happen anymore!
								 //but it did - and it needed corrected
								 //quick fix, comment it out
					//createLeftItem(whereTo);
				} else {
					if(ieorff == 'IE' && loopMe > 1){ //Fir IE7, mostly - won't hurt IE6-, though
						document.getElementById(whereTo).style.lineHeight = '20px';
					}// if(ieorff == 'IE' && loopMe1 > 1)
					for(ser_it = 1; ser_it < loopMe; ser_it++){

						if(window.passed[1][ser_it]['name'] != 'DOMAINSERVER' || typeof(window.passed[1][ser_it]['name']) != 'undefined'){ //demo!!!
							statusCount++;
							createLeftItem(whereTo, window.passed[1][ser_it]['name'], 'server', window.passed[1][ser_it]['workgroup'],window.passed[1][ser_it]['name'],'', 'serIcon');
						}

					}			
					changeStatusBar("Loaded Servers: " + statusCount+ " total");
					createLeftItem(whereTo, 'pmw_blank_hack', '', '', '', '', '');
				}
				if(ieorff!="IE")
					fade(document.getElementById(whereTo), fade_speed, 0, 100);
			} else if(whatToExpect == 'shares'){
				if(whereTo != '')
					forIcon.src='./images/computer.gif';
				var loopMe = window.passed[0].length
				if(loopMe <= 1)
					itemPlus.style.visibility = "hidden";

				if(ieorff == 'IE' && loopMe > 1){
					document.getElementById(whereTo).style.lineHeight = '20px';
				}// if(ieorff == 'IE' && loopMe1 > 1)
				for(sha_it = 1; sha_it < loopMe; sha_it++){
					statusCount++;
					createLeftItem(whereTo, window.passed[0][sha_it]['name'], 'share', window.passed[0][sha_it]['workgroup'],window.passed[0][sha_it]['location'],'', 'fldrIcon');
				}

				changeStatusBar("Loaded Shares: " + statusCount+ " total");
				createLeftItem(whereTo, 'pmw_blank_hack', '', '', '', '');
				if(ieorff!="IE")
					fade(document.getElementById(whereTo), fade_speed, 0, 100);
			}
		} else if (smbCommand == 2){ //we are expecting directories and files
			pageLimit = window.passed['paged'];
			var loopMe1 = window.passed[1].length;
			var loopMe2 = window.passed[0].length;

			if(pageLimit > 0){
				pages = new Array();
				pages = window.passed;
				currentPage = 1;
			}

			var itemNumber = parseInt(whereTo);
			var itemPlus = document.getElementById(itemNumber + "minusBox");

			if(window.passed[1].length <= 1)
				itemPlus.style.visibility = "hidden";

			var forFolder = document.getElementById(parseInt(currentFolder.id)+'iconIcon');
			//create left items
			if(!doFilesOnly){
				forFolder.src = './images/f2_o.gif';
				if(ieorff == 'IE' && loopMe1 > 1){
					document.getElementById(whereTo).style.lineHeight = '20px';
				}// if(ieorff == 'IE' && loopMe1 > 1)
				for(li_it = 1; li_it < loopMe1; li_it++){
					statusCount++;
					if(window.passed[1][li_it]['name'] != '. ' && window.passed[1][li_it]['name'] != '.. ')
						//alert('DIR :'+window.passed[1][li_it]['directory']+':ereh');

						createLeftItem(whereTo, window.passed[1][li_it]['name'], 'directory', window.passed[1][li_it]['workgroup'],window.passed[1][li_it]['location'],window.passed[1][li_it]['directory'],'fldrIcon');
				}
				if(ieorff!="IE")
					fade(document.getElementById(whereTo), fade_speed, 0, 100);
			} else {
				statusCount = window.passed[1].length -1;
			}
			//create right items
			if(!noFiles){
				if(rightSideC.lastChild != null) {//Then we're assuming that we are displaying 
												 //Loading...  This is old code that shouldn't
												 //be needed anymore
					rightSideC.removeChild(rightSideC.lastChild);
				}

				if(loopMe2 > 1){
					rightLocation = window.passed[0][1]['loc'];
					rightDirectory = window.passed[0][1]['dir'];
				}
				//loadingDiv.style.display = 'none';
				if(pageLimit != 0 && loopMe2 > pageLimit){
					for(ri_it = 1; ri_it <= pageLimit; ri_it++){
						statusCount2++;
						createRightItem(window.passed[0][ri_it]['name'],window.passed[0][ri_it]['size'],window.passed[0][ri_it]['wday'],window.passed[0][ri_it]['month'],window.passed[0][ri_it]['day'],window.passed[0][ri_it]['time'],window.passed[0][ri_it]['year'], window.passed[0][ri_it]['icon']);
					}
				} else {
					for(ri_it = 1; ri_it < loopMe2; ri_it++){
						statusCount2++;
						createRightItem(window.passed[0][ri_it]['name'],window.passed[0][ri_it]['size'],window.passed[0][ri_it]['wday'],window.passed[0][ri_it]['month'],window.passed[0][ri_it]['day'],window.passed[0][ri_it]['time'],window.passed[0][ri_it]['year'], window.passed[0][ri_it]['icon']);
					}
				}
				if(loopMe2 == 1){
					createRightItem('No Files in Directory',0,'','','','','', 'none');					
				}
				//jk
				//alert('xx');
				//setToWindow();
			}

			if(pageLimit != 0 && loopMe2 > pageLimit){
				loopMe2--;
				if(statusCount == 0)
					(statusCount2==1)?changeStatusBar("Opened Directory: " + statusCount2+ " of "+ loopMe2 +" files"):changeStatusBar("Opened Directory: " + statusCount2+ " files");
				else if(statusCount2 == 0)
					(statusCount==1)?changeStatusBar("Opened Directory: "+statusCount+" directory"):changeStatusBar("Opened Directory: "+statusCount+" directories");			
				else
					(statusCount==1 && statusCount2 == 1)?changeStatusBar("Opened Directory: " + statusCount2+ " of "+ loopMe2 +" files and "+statusCount+" directory"):changeStatusBar("Opened Directory: " + statusCount2+ " of "+ loopMe2 +" files and "+statusCount+" directories");
			} else { // for pages
				if(statusCount == 0)
					(statusCount2==1)?changeStatusBar("Opened Directory: " + statusCount2+ " file"):changeStatusBar("Opened Directory: " + statusCount2+ " files");
				else if(statusCount2 == 0)
					(statusCount==1)?changeStatusBar("Opened Directory: "+statusCount+" directory"):changeStatusBar("Opened Directory: "+statusCount+" directories");			
				else
					(statusCount==1 && statusCount2 == 1)?changeStatusBar("Opened Directory: " + statusCount2+ " of "+ loopMe2 +" files and "+statusCount+" directory"):changeStatusBar("Opened Directory: " + statusCount2+ " files and "+statusCount+" directories");
			}
		}
		noFiles = false;
		blockLoading = false; //make sure that we are no longer blocking any requests
		endWait();
		loadingOff(1);
		//endTestTime();
	}

	//function do_handleFileMove(fName, dShare, dDir, sShare, sDir, workgroup){
	function do_handleFileMove(objNumber){
		if((rightLocation + rightDirectory)!=(leftLocation[objNumber] +leftDirectory[objNumber])){
			changeText(waitingText,"Moving");
			waitingDiv.style.display="block";
			inQueue = selectedItems.length;

			if(selectedItems.length > 1){
				var fileList = '';
				for(fn_it = 0, ourLen = selectedItems.length-1; fn_it < ourLen; fn_it++){
					fileList = fileList + document.getElementById(selectedItems[fn_it] +'textDiv').innerHTML + ';';
				}
				fileList = fileList + document.getElementById(selectedItems[selectedItems.length-1] +'textDiv').innerHTML;
				x_handleFileMoveMultiple('normal',fileList, username, password, leftLocation[objNumber], leftDirectory[objNumber], rightLocation, rightDirectory, currentWorkgroup, do_handleFileMove_cb);
			}else if(dragTextValue.length > 0) {
				x_handleFileMove('normal',dragTextValue, username, password, leftLocation[objNumber], leftDirectory[objNumber], rightLocation, rightDirectory, currentWorkgroup, do_handleFileMove_cb);
			} else {
				alert('SSLBridge could not find the name of the file you are trying to move.');
				waitingDiv.style.display='none';
				//changeStatus("ERROR: Could not move file");
				//how did I do that?  More imporantly, how did
				//it go by so long w/o detection?
				changeStatusBar("ERROR: Could not move file");
			}
		}
	}

	function do_handleFileMove_cb(z){
		//alert(z);
		inQueue = 0;
		var style = 'Copy';

		 //Added May jk.. This is a complete HACK to make comiled code work
		 // Not sure why but +: is tagged on to begging of string...
         var temp= z.substr(1,2 );
		 if(temp=='+:'){
              z=z.substr(3, z.length);
         }
		 // END of compile hack

		if(z == 'yes'){
			if(inQueue==0){
				for(si_it = 0, ourLen = selectedItems.length; si_it < ourLen; si_it++){
					//rightSideC.removeChild(document.getElementById(selectedItems[si_it]+'listItem'));
					document.getElementById(selectedItems[si_it]+'listItem').style.display='none';
				}
				style = 'Move';
				selectedItems = new Array();
			}
		} else if(z != 'no'){
			if(!errorOff){
				eval("window.passed = " + z);	
				if(window.passed['error'] == 'error'){ //Error catcher
					postError(window.passed['msg']);
					changeStatusBar("ERROR: " + window.passed['msg']);
				}
				errorOff=true;
			}
		}

		if(inQueue==0){
			waitingDiv.style.display="none";
			changeStatusBar("Finished File "+style);
			errorOff=false;
		}
		
	}

	function do_downloadFile(e){
		changeText(waitingText,"Preparing");
		waitingDiv.style.display="block";
		var evt = getEvent(e);


//alert(evt.target.id);

          if(typeof(evt.target.id)=='undefined'){
//alert(evt.target.parentNode.id);
				evt.target.id=evt.target.parentNode.id;

		  }

		var objNumber = parseInt(evt.target.id);



		if(rightClkMenu2.style.display != 'none'){
			objNumber = rightClkMenu2.itemNumber;
			rightClkMenu2.style.display = 'none';
		}

		if(selectedItems.length > 1){
			if(zipMade){
				killZipFile();
			}
			zipMade = true;

			var fileName = '';
			changeStatusBar("Preparing Download: " + selectedItems.length + " files to zip");
			for(fn_it = 0, ourLen = selectedItems.length-1; fn_it < ourLen; fn_it++){
				fileName = fileName + document.getElementById(selectedItems[fn_it] +'textDiv').innerHTML + ';';
			}
			fileName = fileName + document.getElementById(selectedItems[selectedItems.length-1] +'textDiv').innerHTML;
			zipList = fileName;
			zipTime = Date();
			//alert(fileName);
			//zipEnc = z;
			x_downloadMultipleFiles(fileName, rightLocation, rightDirectory, currentWorkgroup, username, password,do_downloadMultipleFiles_cb);			
		} else {
			//var share = rightLocation;
			//var directory = rightDirectory;
			var fileName = document.getElementById(objNumber+"textDiv").innerHTML;
//alert(fileName);
			changeStatusBar("Preparing Download: "+fileName);
			//alert(fileName + ' * ' + share + " * " + directory);
			//alert(username + ' & ' + password);
//alert("rightdirectory==" + rightDirectory);
			//alert(fileName);

//		    fileName=Base64.encode(fileName);

			x_downloadFile(fileName, rightLocation, rightDirectory, currentWorkgroup, username, password, do_downloadFile_cb);
		}
	}

/*
	function do_getTempName(){
		x_getTempName(do_getTempName_cb);
	}

	function do_getTempName_cb(z){
		if(zipMade){
			killZipFile();
		}
		zipMade = true;

		var fileName = '';
		changeStatusBar("Preparing Download: " + selectedItems.length + " files to zip");
		for(fn_it = 0, ourLen = selectedItems.length-1; fn_it < ourLen; fn_it++){
			fileName = fileName + document.getElementById(selectedItems[fn_it] +'textDiv').innerHTML + ';';
		}
		fileName = fileName + document.getElementById(selectedItems[selectedItems.length-1] +'textDiv').innerHTML;
		zipList = fileName;
		zipTime = Date();
		//alert(fileName);
		zipEnc = z;
		x_downloadMultipleFiles(fileName, rightLocation, rightDirectory, currentWorkgroup, username, password, z,do_downloadMultipleFiles_cb);
	}
*/
	function do_downloadFile_cb(z){
		//alert(z);
		// Compile hack JK
         var temp= z.substr(1,2 );
		 if(temp=='+:'){
              z=z.substr(3, z.length);
         }
		 // END of compile hack


		waitingDiv.style.display="none";
		if(z=="c"){
			alert("Praxis and Epiware - Copyright 2005 - 2006");
			return;
		}
		eval("window.passed = " + z);
		if(window.passed['error'] == 'error'){
			changeStatusBar("Error with File Download: Could Not Download");
			postError(window.passed['msg']);			
		} else {

			var url = "./getDL.php?path="+window.passed['path'];
// alert(url);
			//document.location.href=url;
			//alert(url);
			redirectHere(url);
		}
	}

	function do_downloadMultipleFiles_cb(z){

		 //Added May jk.. This is a complete HACK to make comiled code work
		 // Not sure why but +: is tagged on to begging of string...
         var temp= z.substr(1,2 );
		 if(temp=='+:'){
              z=z.substr(3, z.length);
         }
		 // END of compile hack


		waitingDiv.style.display="none";
		if(z=="c"){
			alert("Praxis and Epiware - Copyright 2005 - 2006");
			return;
		}
		eval("window.passed = " + z);
		if(window.passed['error'] == 'error'){
			changeStatusBar("Error with File Download: Could Not Download");
			postError(window.passed['msg']);			
		} else {
			zipMade = true;
			//zipInterval = setInterval("killZipFile()",300000); //5 minutes
			zipEnc = window.passed['path'];
			var url = "./getDL.php?path="+window.passed['path'];
			changeLink(messageText,"Click to Download Zipped Files", url);
			messageDiv.style.display='block';
		}	
	}

	function killZipFile(){
		zipMade = false;
		if(zipInterval != null){
			clearInterval(zipInterval);
			zipInterval=null;
		}
		messageDiv.style.display='none';
		x_killZipFile(zipEnc, do_killZipFile_cb);
	}

	function do_killZipFile_cb(){
		//Nothing
	}

	function zipInfo(){
		var url = "./zipInfo.html";
		//dWindow(url,650,250,10,50);	
		window_make_new(10, 50, 650, 250, url,"SSLBridge - Zip File Information");
	}

	//These keep track of how many folders we have and how many files we have, repsectivly
	var leftItemCount = 0;
	var rightItemCount = 0;

	//function createLeftItem()
	//Creates a folder on the left-hand side
	function createLeftItem(where, ourName, myObjType, myWorkGroup, myLocation, myDirectory, iconClass){
		if(ourName == 'pmw_blank_hack'){
			//this is cheap, I know.  But it works (theoretically).
			//In the case that a workgroup, server, or share doesn't have anything underneath of it, we
			//place this 'emtpy div' there so that when we go to check to see if we need to query for
			//folders/sub-directories it thinks that we don't have to - because we don't.
			//Otherwise, if there where no sub-items to the left-hand item, it would query that every time
			//the user selected it.  
			var newDiv = document.createElement('div');
			newDiv.className = 'emptyHack';
			var putStuffHere= document.getElementById(where);
			putStuffHere.appendChild(newDiv);			
			
			return;
		}

		//ourName = ourName.replace(" ","&nbsp;");
		//alert(ourName);
		var ourCount = leftItemCount;
		leftItemCount++;

		//The wrapper that will hold all content of the left menu item.
		//This will not hold the container
		var wrapperLeft = document.createElement('div');
		wrapperLeft.id = ourCount + 'wrapperLeft';
		wrapperLeft.className = 'wrapperLeft';

		//This creates the plus/minus box that is to the left of each folder
		var plusBox = document.createElement('div');
		plusBox.id =  ourCount + 'plusBox';
		plusBox.className = 'plus';
		var minusBox = document.createElement('div');
		minusBox.id =  ourCount + 'minusBox';
		minusBox.className = 'minus';
		
		var minusIcon = document.createElement('img');
		var plusIcon = document.createElement('img');
		minusIcon.src = './images/plus.gif';
		plusIcon.src = './images/plus.gif';
		plusIcon.id = ourCount + 'plusIcon';
		minusIcon.id = ourCount + 'minusIcon';
		minusBox.appendChild(minusIcon);
		//plusBox.appendChild(plusIcon);

		//minusBox.appendChild(plusBox);
		wrapperLeft.appendChild(minusBox);

		//newDiv will contain the folder/icon and text for the left menu item
		newDiv = document.createElement('div');
		newDiv.id = ourCount + 'leftItem';
		newDiv.className = 'leftItem';

		leftObjType[ourCount] = myObjType;
		leftLocation[ourCount] = myLocation;
		leftDirectory[ourCount] = myDirectory;
		leftWorkgroup[ourCount] = myWorkGroup;

/*
		newDiv.myObjType = myObjType;     //the my* information is used when the event listener 
		minusIcon.myObjType = myObjType;
		plusBox.myObjType = myObjType;
		newDiv.myLocation = myLocation;   //is triggered
		newDiv.myWorkgroup = myWorkGroup;
		newDiv.myDirectory = myDirectory;
		plusBox.myLocation = myLocation;  
		plusBox.myWorkgroup = myWorkGroup;
		plusBox.myDirectory = myDirectory;
		minusIcon.myLocation = myLocation;   
		minusIcon.myWorkgroup = myWorkGroup;
		minusIcon.myDirectory = myDirectory;
*/
		minusIcon.state = 'closed';
		
		var iconDiv = document.createElement('div');
		var iconIcon = document.createElement('img');
		iconIcon.id = ourCount + 'iconIcon';
		iconDiv.id = ourCount + 'leftIcon';
		iconDiv.className = iconClass;
		if(iconClass == 'wgIcon'){
			iconIcon.src = './images/network.gif';
		} else if(iconClass == 'serIcon'){
			iconIcon.src = './images/computer.gif';
		} else if(iconClass == 'fldrIcon'){
			iconIcon.src = './images/f2_c.gif';
		}
		iconDiv.appendChild(iconIcon);

		wrapperLeft.appendChild(iconDiv);

		//for the dropdown.gif
		if(ieorff=="FF"){
			dropDiv = document.createElement('div');
			var dropIcon = document.createElement('img');
			dropIcon.id=ourCount+'dropIcon';
			dropDiv.id=ourCount+'dropDiv';
			dropIcon.className="dropIcon2";
			dropDiv.className="dropIcon";
			dropIcon.src='./images/dropup.gif';
			dropDiv.appendChild(dropIcon);
		} else {
			dropDiv = document.createElement('div');
			dropDiv.id=ourCount+'dropDiv'
			dropDiv.className = "dIconIE";
			//dropDiv.style.fontFamily = "wingdings";
			//dropDiv.innerText='�';
			dropDiv.innerText='V';
		}

		wrapperLeft.appendChild(dropDiv);
		
		var anchorLink = document.createElement('a');

		anchorLink.id = ourCount + 'link';

		anchorLink.setAttribute('href', 'javascript:LoadSubdir('+ourCount+');');

		anchorLink.className = 'leftItemAnchor';
		anchorLink.style.whiteSpace='nowrap';
		anchorLink.hideFocus = true;

		//anchorLink.setAttribute('onclick','this.hideFocus=true');

		anchorLink.myCW = "Pxi an EW 2k5 2k6";

		if(ieorff == 'IE'){
			//IE requires that if you are moving a positionned element via the dom (which we do)
			//that it be explicitly stated in the javascript code what value it is...  making
			//style sheets worthless...
			//blah...
			anchorLink.innerText = ourName;
			if(ie7){ //What a hack...  Thanks, JScript!
				anchorLink.style.left="18px";
			} else {
				anchorLink.style.left="0px";
			}//end if(ie7)
		} else {
			var newText = document.createTextNode(ourName);  //**
			anchorLink.appendChild(newText);
			anchorLink.style.left="34px";
		}


		newDiv.appendChild(anchorLink);
		newDiv.setAttribute('unselectable','on');

		var colDiv = document.createElement('div');  //This is the 'container' that will be underneath the folder.
		colDiv.id = newDiv.id + 'Container';		 //The container holds all of the sub-directories of a folder.
		colDiv.className = 'container';
		colDiv.style.display='none'; //Donno why I have to specify
		
		wrapperLeft.appendChild(newDiv);
		//wrapperLeft.style.border='1px solid #ff0000';
		wrapperLeft.style.overflow='Hidden';
		wrapperLeft.style.width='600px';

		putStuffHere= document.getElementById(where);

		//putStuffHere.style.border='1px solid #dd00ff';
		putStuffHere.style.width='600px';

		putStuffHere.appendChild(wrapperLeft);
		putStuffHere.appendChild(colDiv);

		addEvent('mousedown', openClose,newDiv);
		//addEvent('mouseup', unclickOverLeft,newDiv);
		addEvent('mousedown', openClose,iconDiv);
		//addEvent('mouseup', unclickOverLeft,iconDiv);
		addEvent('mousedown', clickPlus,minusIcon);

/*
		xAddEventListener(newDiv, 'mousedown', openClose, true);
		xAddEventListener(newDiv, 'mouseup', unclickOverLeft, true);
		xAddEventListener(iconDiv, 'mousedown', openClose, true);
		xAddEventListener(iconDiv, 'mouseup', unclickOverLeft, true);
		xAddEventListener(minusIcon, 'mousedown', clickPlus, true);
*/
		if(iconClass=='fldrIcon'){
			//xAddEventListener(dropDiv, 'mousedown', callLeftMenu, true);
			addEvent('mousedown',callLeftMenu,dropDiv);
		}
	}

	function LoadSubdir(objNumber){ 
		//I use to sit here and do nothing, but now that IE has decided that 
		//it it wants me to die, I have to fill this function with a bunch
		//of junk that is just going to slow down the app
		var verdict = false;
		if(prevFolder.id){ 
		  if(parseInt(prevFolder.id) == objNumber){
			verdict = true;
          }
        }
		var iconDiv = document.getElementById(objNumber + 'iconIcon');
		var elem = document.getElementById(objNumber + 'leftItem');
		var container = document.getElementById(objNumber + 'leftItemContainer');

		currentLocation = leftLocation[objNumber];
		currentWorkgroup = leftWorkgroup[objNumber];
		currentDirectory = leftDirectory[objNumber];

		var ourType = leftObjType[objNumber];
		var image = '';
		switch(ourType){
			case 'workgroup':
				image = './images/network.gif';
				break;
			case 'server':
				image = './images/computer.gif';
				break;
		}

		var plusminus = document.getElementById(objNumber + 'minusIcon');

		if(ourType == 'workgroup' || ourType == 'server') {
			if(container.style.display=='none')
				plusminus.src='./images/plus.gif';
			else
				plusminus.src='./images/minus.gif';
		} else if(verdict && plusminus.state == 'open'){
			if(image == '')
				image = './images/f2_c.gif';
			plusminus.src='./images/plus.gif';
			plusminus.state='closed';
		} else {
			if(image == '')
				image = './images/f2_o.gif';
			plusminus.src='./images/minus.gif';
			plusminus.state='open';
		}

		iconDiv.src=image;
	}

	//function createRightItem()
	//Creates a file entry on the right browser, giving it an event listener as well
	function createRightItem(ourName, ourSize, ourWday, ourMonth, ourDay, ourTime, ourYear, icon){
		var ourCount = rightItemCount;
		rightItemCount++; //keep track of how many we have made so far
		
		if(icon == "none"){ //needs updated
			newDiv = document.createElement('div'); //this is our holder
			newDiv.id = ourCount + 'rightItem';
			newDiv.className = 'rightItem';
			var textDiv = document.createElement('div');
			textDiv.id = ourCount + 'textDiv';
			textDiv.className = 'rightTextDiv';	

			textDiv.style.left="18px";


			if(ieorff=='IE'){
				textDiv.innerText = ourName;

				textDiv.style.left="-18px";

			} else {
				var newText = document.createTextNode(ourName);
				textDiv.appendChild(newText);
				textDiv.style.width="50%";
			}
			
			var bar = document.createElement('div');
			bar.className = 'rightBar';
			bar.id = ourCount + 'rightBar';
			
			textDiv.setAttribute('unselectable','on');
			newDiv.appendChild(textDiv);

			newDiv.appendChild(bar);

			rightSideC.appendChild(newDiv);
		} else {	
			//newDiv
			//newDiv will be the holder for all of the items for a right-side element
/*
			var newDiv = document.createElement('div'); //this is our holder
			newDiv.id = ourCount + 'rightItem';
			if(ieorff == 'IE'){
				newDiv.className = 'rightItemIE';
			} else {
				newDiv.className = 'rightItem';
			}

			if(ourCount != 0 && OSName == "MacOS")
				newDiv.style.border="1px white solid";
*/
			var newDiv = rightTemplate.cloneNode(true);
			newDiv.id = ourCount + 'rightItem';
			if(ieorff == 'IE'){
				newDiv.className = 'rightItemIE';
			} else {
				newDiv.className = 'rightItem';
			}

			if(ourCount != 0 && OSName == "MacOS")
				newDiv.style.border="1px white solid";

			//textDiv
			//textDiv will hold the file name that is being generated
/*
			textDiv = document.createElement('div');
			textDiv.id = ourCount + 'textDiv';
			textDiv.className = 'rightTextDiv'; 

			textDiv.style.left="0px";
			if(ieorff=='IE'){
				textDiv.style.left="-17px";
				textDiv.innerText=ourName;
			} else {
				textDiv.style.left="0px";
				textDiv.appendChild(document.createTextNode(ourName));
			}
*/
			var textDiv = newDiv.childNodes[3];
			textDiv.id = ourCount + 'textDiv';
			textDiv.className = 'rightTextDiv_pl'; 


//ourName=ourName + '---------';

//            ourName=Base64.decode(ourName);


			//textDiv.style.left="0px";
			if(ieorff=='IE'){
				//textDiv.style.left="-17px";
				textDiv.innerText=ourName;
			} else {
				//textDiv.style.left="0px";
				textDiv.appendChild(document.createTextNode(ourName));
			}
/*
			if(useRightIcons){
				//make the file icon
				if(ieorff == 'FF'){
					iconDiv = document.createElement('img');
					iconDiv.id = ourCount + 'rightIcon';
					iconDiv.src = './images/'+icon;
					iconDiv.className = 'fIcon';

					dropDiv = document.createElement('img');
					dropDiv.className = "dIcon";
					dropDiv.src='./images/dropdown.gif';
				} else {
					var iconDiv = document.createElement('div');
					iconDiv.id = ourCount + 'rightIcon';
					iconDiv.className = 'fIconIE';

					var dropDiv = document.createElement('div');
					dropDiv.className = "dIconIE";
                    //dropDiv.innerText='�';
					dropDiv.innerText='�'
					//var dropDivText = document.createElement('text');
                    // ropDiv.appendChild(dropDivText);

				}
				dropDiv.id=ourCount+'dropIconR';
			}
*/
			var iconDiv = newDiv.childNodes[1];
			var dropDiv = newDiv.childNodes[2];
			if(useRightIcons){
				if(ieorff == 'FF'){
					iconDiv.id = ourCount + 'rightIcon';
					iconDiv.src = './images/'+icon;
					iconDiv.className = 'fIcon';

					dropDiv.id = ourCount + 'dropIconR';
					dropDiv.className = "dropIconRight";
					dropDiv.src='./images/dropdown.gif';
					//this shouldn't be here - what's going on?
					dropDiv.style.display = 'none';
				} else {
					iconDiv.id = ourCount + 'rightIcon';
					iconDiv.className = 'fIconIE';

					dropDiv.id = ourCount + 'dropIconR';
					dropDiv.className = "dropIconRightIE";
					//dropDiv.innerText='�'
					dropDiv.innerText='V'
				}
			}

/*
			var floatieDiv = document.createElement('div'); //this will hold the content that will float
			floatieDiv.className = 'rightItemInfo';			//on the right of the title
			floatieDiv.id = ourCount + 'floatieDiv';

			var rightItemRight = document.createElement('div');
			rightItemRight.className = "rightItemRight";
			rightItemRight.id = ourCount + "infoDiv";
			var rightItemLeft = document.createElement('div');
			rightItemLeft.className = "rightItemLeft";
			rightItemLeft.id = ourCount + "sizeDiv";

			var rightInfo = ourMonth+ ' ' +ourDay+ ' '+ourTime+' '+ourYear;
		
			if(ieorff == 'IE'){
				rightItemLeft.innerText = ourSize;
				rightItemRight.innerText = rightInfo;
			} else {
				rightItemLeft.appendChild(document.createTextNode(ourSize));
				rightItemRight.appendChild(document.createTextNode(rightInfo));
			}

			floatieDiv.appendChild(rightItemLeft);
			floatieDiv.appendChild(rightItemRight);

			//var bar = document.createElement('div');
			//bar.className = 'rightBar';
			//bar.id = ourCount + 'rightBar';
*/
			var floatieDiv = newDiv.childNodes[0];
			var rightItemRight = floatieDiv.childNodes[1];
			var rightItemLeft = floatieDiv.childNodes[0];
			floatieDiv.className = 'rightItemInfo';			//on the right of the title
			floatieDiv.id = ourCount + 'floatieDiv';


			rightItemRight.className = "rightItemRight";
			rightItemRight.id = ourCount + "infoDiv";

			rightItemLeft.className = "rightItemLeft";
			rightItemLeft.id = ourCount + "sizeDiv";

			var rightInfo = ourMonth+ ' ' +ourDay+ ' '+ourTime+' '+ourYear;
		


			if(ieorff == 'IE'){
				rightItemLeft.innerText = ourSize;
				rightItemRight.innerText = rightInfo;
			} else {
				rightItemLeft.appendChild(document.createTextNode(ourSize));
				rightItemRight.appendChild(document.createTextNode(rightInfo));
			}

			textDiv.setAttribute('unselectable','on');
			floatieDiv.setAttribute('unselectable','on');

//			var rightBlock = document.createElement('div');
//			rightBlock.className = "rightBlock";

/*
			if(useRightIcons){newDiv.appendChild(iconDiv);}
			newDiv.appendChild(dropDiv);
			newDiv.appendChild(floatieDiv); //attach the text and floater to our div
			newDiv.appendChild(textDiv);
			//newDiv.appendChild(bar);  //Don't need anymore, I don't think
*/
//newDiv.style.border='1px solid white ';
			var addMe = document.createElement('li');
			addMe.className = 'rightSideListItem';
			addMe.id = ourCount + "listItem";
			addMe.appendChild(newDiv);

            //added by JK.. prevent step effect when window too small in x direction
			var breaker = document.createElement('div');
            breaker.style.clear="both"; 
			addMe.appendChild(breaker);
    
 			rightSideC.appendChild(addMe);

			//alert(addMe.id);

			/*
			if(ieorff=="IE"){
				var breakDiv = document.createElement('br');
				breakDiv.id=ourCount + "break";
				breakDiv.style.height="0px";
				breakDiv.style.fontSize="0pt";
				rightSideC.appendChild(breakDiv);
			}
			*/

			//listeners
			if(OSName == "MacOS"){
				//xAddEventListener(textDiv, 'mouseup', mac_itemUp, true);
				//xAddEventListener(textDiv, 'mousedown', mac_itemSelect, true);
				addEvent('mouseup',mac_itemUp,textDiv);
				addEvent('mousedown',mac_itemSelect,textDiv);
			} else{
				//xAddEventListener(textDiv, 'mousedown', itemSelect, true);
				//addEvent('mousedown',itemSelect,textDiv);
			}
		}
	}

	/******************************************************
	  For paging functionality
	  Incomplete
	  vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	******************************************************/
	function nextPage(){
		pagedOver(currentPage + 1);
	}

	function prevPage(){
		pagedOver(currentPage - 1);
	}

	function selePage(pageID){
		pagedOver(pageID);
	}

	function pagedOver(newPage){
		blockLoading = true;
		beginWait();
		loadingOn(15);
		var loopMe2 = pages[0].length;
		var statusCount2 = 0;

		var lowerLimit = 0;
		var upperLimit = 0;

		currentPage = newPage;

		lowerLimit = ((newPage -1) * pageLimit) +1;
		upperLimit = lowerLimit + pageLimit - 1;
		if(upperLimit > loopMe2)
			upperLimit = loopMe2;

		currentPage = newPage;

		clearRight();

		for(ri_it = lowerLimit; ri_it < upperLimit; ri_it++){	
			statusCount2++;
			createRightItem(pages[0][ri_it]['name'],pages[0][ri_it]['size'],pages[0][ri_it]['wday'],pages[0][ri_it]['month'],pages[0][ri_it]['day'],pages[0][ri_it]['time'],pages[0][ri_it]['year'],pages[0][ri_it]['loc'],pages[0][ri_it]['dir'], pages[0][ri_it]['icon']);
		}
		if(loopMe2 == 1){
			createRightItem('No Files in Directory',0,'','','','','','','', 'none');					
		}

		loopMe2--;
		changeStatusBar("Paged Over: " + lowerLimit+ " - "+ upperLimit+" of "+ loopMe2 +" files");

		blockLoading = false; //make sure that we are no longer blocking any requests
		endWait();
		loadingOff(6);
	}
	/******************************************************
	  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	  For paging functionality
	  Incomplete
	******************************************************/


	//function clearRight()
	//Removes every file from the right hand side
	function clearRight(waitOff){
		loadingOn(2);
		var counter = rightItemCount;
		rightItemCount = 0; //since we are removing them, we can reset the count

		//The following code is commented out because this adds half of the load time of a 
		//directory into the load of a new directory - as in when you click on the mrc directory
		//that has 1200 files, it takes between 10 - 25 seconds to load (depending upon the connection)
		//and would add another 5 - 12 seconds to unload each listener.
		//So the current way is a lot faster, BUT it leaks memory (the old listeners).
		//JK approved this change.
		//I'll try to optomize it a bit later. - PMW1302

		//We remove the listeners from each element.  Keeps things cleaner and gives 
		//JS less to mess up
		/*
		for(re_it = 0; re_it < counter; re_it++){
			xRemoveEventListener(rightSide.lastChild.id, 'mousedown', itemSelect, false);
			rightSide.removeChild(rightSide.lastChild);
		}
		*/
		rightSide.removeChild(rightSideC);
		rightSideC = document.createElement('ul');
		rightSideC.className = 'rightSideList';

//rightSideC.style.borderLeft='1px solid white';
//rightSideC.style.height='100%';

		rightSide.appendChild(rightSideC);
		
		if(waitOff == 'yesplease')
			loadingOff(2);
		selectedItems = new Array();
	}

	//function openClose()
	//Any time an item on the left-hand side is selected, openClose should be called.  It will handle
	//the opening and closing of workgroups, servers, shares, and directories
	function openClose(e, opt){
		if(!blockLoading){
			//testTime();
			if(typeof(opt)=="undefined")
				opt = "go";
			//else opt == "noClear";
			loadingOn(3);
			
			var evt = getEvent(e);
//			if(evt.target.nodeType==3) //for mac/safari
//				evt.target = evt.target.parentNode;
			//hack
//alert(evt.target.id);
			if(typeof(evt.target.id) == "undefined")
				evt.target.id = evt.target.parentNode.id;

			var folderNumber = parseInt(evt.target.id);
			currentFolder = document.getElementById(folderNumber+"leftItem");
			var currentFolderLink = document.getElementById(folderNumber+"link");

			//other variables that I'll need
			//they are set to do a share/directory load by default
			var theLoc = leftLocation[folderNumber];
			var theWG = leftWorkgroup[folderNumber];
			var theDir = leftDirectory[folderNumber];
 
			var useMe = 'yes';
			var theComm = '2';
			var optName = '';
			
			//first we will see if this is a right click
			if(opt!="noClear" && e.button == 2 && (leftObjType[folderNumber] == 'share' || leftObjType[folderNumber] == 'directory')){
				loadingOff(3);
				/*
				if(evt.attachEvent){
					rightClkMenu.style.top = (evt.clientY) + 'px';
					rightClkMenu.style.left = (evt.clientX)+ 'px';
				} else {
					rightClkMenu.style.top = (evt.pageY) + 'px';
					rightClkMenu.style.left = (evt.pageX) + 'px';
				}
				rightClkMenu.style.display='block';
				if(rightClkMenu2.style.display != 'none')
					rightClkMenu2.style.display = 'none';
				//Setup data
				rightClkMenu.myLocation = currentFolder.myLocation;
				rightClkMenu.myWorkgroup = currentFolder.myWorkgroup;
				rightClkMenu.myDirectory = currentFolder.myDirectory;
				*/
				return;
			} else { //it is a regular click - either on the plus/minus or on the folder
				var currentContainer = document.getElementById(folderNumber+"leftItemContainer");
				whereTo = currentContainer.id;
				if(rightClkMenu.style.display != 'none') //close any open right-click menues
					rightClkMenu.style.display = 'none';
				if(rightClkMenu2.style.display != 'none')
					rightClkMenu2.style.display = 'none';
				var ourPlus = document.getElementById(folderNumber+"minusIcon");
				var ourFolder = document.getElementById(folderNumber+"iconIcon");
				if(currentFolder.id != selectedFolder.id){ //is this a different folder than we selected previously?
					if(opt!="noClear"){ //if we clicked on the folder and not the plus/minus
						clearRight();
						if(selectedFolder != ''){
							dehilight_left(parseInt(selectedFolder.id));
						}
						hilight_left(parseInt(currentFolder.id));
						selectedFolder = currentFolder;
					} else {
						//adjust picture for plus/minus I suppose
						//not needed here
					}

					if(currentContainer.style.display == "none"){ //is the container closed?
						currentContainer.style.display = "block"; //open the container
						ourPlus.src = "./images/minus.gif";
						ourPlus.state = "open";

						if(currentContainer.lastChild==null){ //we assume that when we are clicking
															  //that if there are no children in the container
															  //we have that we have to populate it
							doFilesOnly=false; //if we are populating files, this asks if we need to do the left menu, too
							if(leftObjType[folderNumber] == 'workgroup'){
								whatToExpect ='servers';
								theComm = '1';
								useMe = 'no';
								smbCommand = 1;
							} else if(leftObjType[folderNumber] == 'server'){
								whatToExpect = 'shares';
								opt = "server";
								theComm = '3';
								useMe = 'no';
								smbCommand = 1;
							} else  if(leftObjType[folderNumber] == 'share' || leftObjType[folderNumber] == 'directory'){
								ourFolder.src = "./images/f2_o.gif";
								//this should happen the most, so the rest of the variables are set to do 
								//this by default - see above
								smbCommand = 2;
								whatToExpect = "directories";
							} else {
								//something has gone wrong - we have picked up an event who's object
								//does not have a myObjType.  I don't know what to do in this case.
							}
							//alert(useMe + ' ' + theLoc + ' ' + theComm + ' ' + theWG + ' ' + theDir  + ' ' + whatToExpect + ' ' + smbCommand);
							do_handleRequest(useMe, theLoc, theComm, theWG, theDir, opt);	
						} else { //there are children!  praise the lord!
							if(leftObjType[folderNumber] == "workgroup" || leftObjType[folderNumber] == "server"){
								loadingOff();
							} else if (leftObjType[folderNumber] == 'share' || leftObjType[folderNumber] == 'directory'){
								doFilesOnly = true;
								smbCommand = 2;
								whatToExpect = "directories";
								do_handleRequest(useMe, theLoc, theComm, theWG, theDir, opt);	
							}
							if(ieorff!="IE")
								fade(currentContainer, fade_speed, 0, 100);
						}
					} else if(currentContainer.style.display == "block"){ //is the container open?
						//fade(currentContainer, fade_speed, 100, 0);
						if(leftObjType[folderNumber] == "workgroup" || leftObjType[folderNumber] == "server"){
							loadingOff();
						} else if (leftObjType[folderNumber] == 'share' || leftObjType[folderNumber] == 'directory'){
								doFilesOnly = true;
								smbCommand = 2;
								whatToExpect = "directories";
								do_handleRequest(useMe, theLoc, theComm, theWG, theDir, opt);	
						}
					}
				} else if(currentFolder.id == selectedFolder.id){ //is this the same folder we just clicked on?
					//These cases are just here for comepleteness.  it doesn't slow down the app much, and I
					//actually changed what these functions use to do from the previous version of this code
					if(currentContainer.style.display == "none"){ //is the container closed?
						if(leftObjType[folderNumber] == 'share' || leftObjType[folderNumber] == 'directory')
							ourFolder.src = "./images/f2_c.gif";
						loadingOff();
						currentContainer.style.display = "block";
						if(ieorff!="IE")
							fade(currentContainer, fade_speed, 0, 100);
					} else if(currentContainer.style.display == "block"){ //is the container open?
						loadingOff();
						//fade(currentContainer,fade_speed,1,100);
					}
				}

			}
		}//end if(!blockLoading)
	}

	function clickPlus(e){
		loadingOn(9);
		noFiles=true;
		var evt = getEvent(e);
		var objNumber = parseInt(evt.target.id);
		var plusminus = document.getElementById(objNumber + 'minusIcon');
		var ourContainer = document.getElementById(objNumber + 'leftItemContainer');
		if(leftObjType[objNumber] == 'directory' || leftObjType[objNumber] == 'share')
			 ourFolder = document.getElementById(objNumber + 'iconIcon');
		else
			ourFolder = null;
		if(plusminus.state=='closed' || typeof(plusminus.state)=='undefined'){
			plusminus.state = 'open';
			if(ourContainer.lastChild != null){
				plusminus.src='./images/minus.gif';
				if(ourFolder != null)
					ourFolder.src = "./images/f2_o.gif";
				ourContainer.style.display='block';
				if(ieorff!="IE")
					fade(ourContainer, fade_speed, 0, 100);
				loadingOff(9);
				noFiles = false;
			}else{
				openClose(e, 'noClear');
			}
			/*
			if(ourFolder != null)
				ourFolderplusminus.src='./images/f2_o.gif';
			*/
		} else { //it's dipslay == none
			if(ieorff!="IE")
				fade(ourContainer, fade_speed, 100, 0);
			plusminus.state = 'closed';
			plusminus.src='./images/plus.gif';
			ourContainer.style.display='none';
			if(ourFolder != null)
				ourFolder.src='./images/f2_c.gif';
			loadingOff(9);
			noFiles = false;
		}
	}
	/*
	//onLeftOver and onLeftOut are no longer needed
	//CSS is taking care of the hilighting
	function onLeftOver(e){
		var evt = getEvent(e);
		var number = parseInt(evt.target.id);
		var elem = document.getElementById(number + 'leftItem');
		if(elem.className != 'leftItemClick'){
			//elem.className = 'leftItemOver';
			//elem.style.backgroundColor = 'red';
			//elem.style.color = 'white';
		}
	}
	//onLeftOver and onLeftOut are no longer needed
	//CSS is taking care of the hilighting
	function onLeftOut(e){
		var evt = getEvent(e);
		var number = parseInt(evt.target.id);
		var elem = document.getElementById(number + 'leftItem');
		if(elem.className != 'leftItemClick'){
			//elem.style.backgroundColor = 'white';
			//elem.style.color = 'black';
			//elem.className = 'leftItem';	
		}
	}
	*/
	function mac_itemUp(e){
		if(e.ctrlKey){
			/*
			var evt = getEvent(e);
			if(evt.target.nodeType==3)
				evt.target = evt.target.parentNode;
			var itemNumber = parseInt(evt.target.id);
			unselectSelected();
			hilight(itemNumber);
			selectedItems.push(itemNumber);
			if(evt.attachEvent){
				rightClkMenu2.style.top = (evt.clientY) + 'px';
				rightClkMenu2.style.left = (evt.clientX)+ 'px';
			} else {
				rightClkMenu2.style.top = (evt.pageY) + 'px';
				rightClkMenu2.style.left = (evt.pageX) + 'px';
			}
			rightClkMenu2.itemNumber = itemNumber;
			rightClkMenu2.style.display='block';
			if(rightClkMenu.style.display != 'none')
				rightClkMenu.style.display = 'none';
			*/
		}
	}

	function mac_itemSelect(e){
		blockAreaClick = true;
		var evt = getEvent(e);
		var itemNumber = parseInt(evt.target.id);
		if(itemNumber >= 0){
			//do nothing
		} else if(Safari){
			itemNumber = parseInt(evt.target.parentNode.id);
		}
		if(e.shiftKey && OSName == 'MacOS'){ //control-click
			if(foundEarlier(itemNumber,true)) { //remove the itme

				dehilight(itemNumber);
			} else { //add the item

				hilight(itemNumber);
				//let the user drag the element
				if(e.button != 2 || selectedItems.length > 1)
					startDrag(e, document.getElementById(itemNumber +'textDiv').innerHTML);
				selectedItems.push(itemNumber);
			}
		} else if(!foundEarlier(itemNumber,false)){ //haven't clicked this item
			unselectSelected();

			hilight(itemNumber);
			//let the user drag the element
			if(e.button != 2 || selectedItems.length > 1)
				startDrag(e, document.getElementById(itemNumber +'textDiv').innerHTML);
			selectedItems.push(itemNumber);
		} else {//we've clicked this item before - just start dragging
			if(e.button != 2 || selectedItems.length > 1)
				startDrag(e, document.getElementById(itemNumber +'textDiv').innerHTML);
		}
		if(e.button == 2 && selectedItems.length <= 1){
			/*
			if(evt.attachEvent){
				rightClkMenu2.style.top = (evt.clientY) + 'px';
				rightClkMenu2.style.left = (evt.clientX)+ 'px';
			} else {
				rightClkMenu2.style.top = (evt.pageY) + 'px';
				rightClkMenu2.style.left = (evt.pageX) + 'px';
			}
			rightClkMenu2.itemNumber = itemNumber;
			rightClkMenu2.style.display='block';
			*/
			if(rightClkMenu.style.display != 'none')
				rightClkMenu.style.display = 'none';
		} else if(rightClkMenu2.style.display != 'none'){
			rightClkMenu2.style.display='none';
			if(rightClkMenu.style.display != 'none')
				rightClkMenu.style.display = 'none';
		}
		//In Firefox, areaClick finishes before selectItem starts.  To satisfy this
		//race condition, this must called FOR FF/NS ONLY
		//if(navigator.appName=="Netscape")
		//	blockAreaClick = false;  
	}
	
	function itemSelect(itemNumber, ctrl, shift, right){
		blockAreaClick = true;
		//var evt = getEvent(e);
		//var itemNumber = parseInt(evt.target.id);
		if(itemNumber >= 0){
			//do nothing
		} else if(Safari){
			//itemNumber = parseInt(evt.target.parentNode.id);
		}
		//if((e.ctrlKey && OSName != 'MacOS')||(e.shiftKey && OSName == 'MacOS')){ //control-click
		if((ctrl && OSName != 'MacOS')||(shift && OSName == 'MacOS')){ //control-click
			if(foundEarlier(itemNumber,true)) { //remove the itme
				becauseISaySo=true;
				dehilight(itemNumber);
				scootNext();
			} else { //add the item
				hilight(itemNumber);
				//let the user drag the element
				if(!right|| selectedItems.length > 1){
					startDrag(document.getElementById(itemNumber +'textDiv').innerHTML, itemNumber);
					//startDrag(e, document.getElementById(itemNumber +'textDiv').innerHTML);
				}
				shiftPivot = itemNumber;
				shiftPrevious = '';
				selectedItems.push(itemNumber);
			}
//		} else if(e.shiftKey && OSName != 'MacOS'){ //shift-click
		} else if(shift && OSName != 'MacOS'){ //shift-click
			if(selectedItems.length < 1){
				shiftPrevious = '';
				shiftPivot='';
				hilight(itemNumber);
            }
			executeShiftSelect(itemNumber);
		} else if(!foundEarlier(itemNumber,false)){ //haven't clicked this item
			unselectSelected();
			hilight(itemNumber);
			//let the user drag the element
			if(!right || selectedItems.length > 1)
				startDrag(document.getElementById(itemNumber +'textDiv').innerHTML, itemNumber);
			selectedItems.push(itemNumber);
			shiftPivot = itemNumber;		
			shiftPrevious = '';
		} else {//we've clicked this item before - just start dragging
			if(!right|| selectedItems.length > 1)
				startDrag(document.getElementById(itemNumber +'textDiv').innerHTML, itemNumber);
			shiftPivot = itemNumber;
		}
//		if(e.button == 2 && selectedItems.length <= 1){
		if(right && selectedItems.length <= 1){
			/*
			if(evt.attachEvent){
				rightClkMenu2.style.top = (evt.clientY) + 'px';
				rightClkMenu2.style.left = (evt.clientX)+ 'px';
			} else {
				rightClkMenu2.style.top = (evt.pageY) + 'px';
				rightClkMenu2.style.left = (evt.pageX) + 'px';
			}
			rightClkMenu2.itemNumber = itemNumber;
			rightClkMenu2.style.display='block';
			*/
			if(rightClkMenu.style.display != 'none')
				rightClkMenu.style.display = 'none';
		} else if(rightClkMenu2.style.display != 'none'){
			rightClkMenu2.style.display='none';
			if(rightClkMenu.style.display != 'none')
				rightClkMenu.style.display = 'none';
		}
		//In Firefox, areaClick finishes before selectItem starts.  To satisfy this
		//race condition, this must called FOR FF/NS ONLY
		//if(navigator.appName=="Netscape")
		//	blockAreaClick = false;  
	}


	function hilight(itemNumber){
		var textHere = document.getElementById(itemNumber + 'textDiv');
		var infoHere = document.getElementById(itemNumber + 'rightItemRight');
		var dateHere = document.getElementById(itemNumber + 'sizeDiv');
		var sizeHere = document.getElementById(itemNumber + 'infoDiv');
		var rightHere = document.getElementById(itemNumber + 'rightItem');

		dateHere.style.backgroundColor='blue'; //background
		sizeHere.style.backgroundColor='blue';
		textHere.style.backgroundColor='blue';
		//infoHere.style.backgroundColor='blue';
		rightHere.style.backgroundColor='blue';
		dateHere.style.color="white"; //font
		sizeHere.style.color="white";
		textHere.style.color="white";
		//infoHere.style.color="white"; // ??
		//rightHere.style.border='1px solid blue';

		if(selectedItems.length < 1){
			var rightDrop = document.getElementById(itemNumber+"dropIconR");	
			rightDrop.style.display = 'inline';
		}
/*
		var rightDrop = document.getElementById(itemNumber+"dropIconR");	
		if(selectedItems.length<1){
			if(OSName != "MacOS"){
				if(ieorff == "FF"){
					textHere.style.left="19px";
					rightDrop.style.opacity = (1.0);
					rightDrop.style.MozOpacity = (1.0);
					rightDrop.style.KhtmlOpacity = (1.0);
				}else {
					textHere.style.left="1px";
					rightDrop.style.filter = "alpha(opacity=100)"; 
				}
				//scoot(textHere, 1, 19);
				//fade(rightDrop, fade_speed, 0, 100);
			} else {
				rightHere.style.border = "1px solid blue";
				textHere.style.left="19px";
				rightDrop.style.KhtmlOpacity="1.0";
				rightDrop.style.opacity="1.0";
			}
			//xAddEventListener(rightDrop, 'mousedown', callRightMenu , true);
			addEvent('mousedown', callRightMenu , rightDrop);
		}
*/		
    }


	function dehilight(itemNumber){
 		var textHere = document.getElementById(itemNumber + 'textDiv');
		var infoHere = document.getElementById(itemNumber + 'rightItemRight');
		var dateHere = document.getElementById(itemNumber + 'sizeDiv');
		var sizeHere = document.getElementById(itemNumber + 'infoDiv');
		var rightHere = document.getElementById(itemNumber + 'rightItem');
		dateHere.style.backgroundColor='white'; //background
		sizeHere.style.backgroundColor='white';
		textHere.style.backgroundColor='white';
		//infoHere.style.backgroundColor='white';
		rightHere.style.backgroundColor='white';

   		 //rightHere.style.border='1px white solid';

		dateHere.style.color="black"; //font
		sizeHere.style.color="black";
		textHere.style.color="black";

		//infoHere.style.color="black"; //??

		if(selectedItems[0] == itemNumber || becauseISaySo){
          //alert(itemNumber);
			var rightDrop = document.getElementById(itemNumber+"dropIconR");
			rightDrop.style.display = 'none';
			becauseISaySo = false;
		}
			/*
			if(OSName != "MacOS"){
				if(ieorff == "FF")
					textHere.style.left="0px";
				else 
					textHere.style.left="-18px";
				becauseISaySo = false;

			var rightDrop = document.getElementById(itemNumber+"dropIconR")
			rightDrop.style.opacity = (0.0);
			rightDrop.style.MozOpacity = (0.0);
			rightDrop.style.KhtmlOpacity = (0.0);
			rightDrop.style.filter = "alpha(opacity=0)"; 
				//scoot(textHere, 0, 19);
				//fade(document.getElementById(itemNumber+"dropIconR"), fade_speed, 100, 0);
			} else {
				rightHere.style.borderColor="1px solid white";
				textHere.style.left="0px";
				document.getElementById(itemNumber+"dropIconR").style.KhtmlOpacity=".0";
				document.getElementById(itemNumber+"dropIconR").style.opacity=".0";				
			}
			//xRemoveEventListener(document.getElementById(itemNumber+"dropIconR"), 'mousedown', callRightMenu , true);
			removeEvent('mousedown', callRightMenu , document.getElementById(itemNumber+"dropIconR"));
		}
		*/
    }

	function scootNext(){
		var itemNumber = selectedItems[0];
//alert(itemNumber);
         if(selectedItems.length>0){
		  var textHere = document.getElementById(itemNumber + 'textDiv');
		  document.getElementById(itemNumber+"dropIconR").style.display='inline';
		 }  
		//scoot(textHere, 1, 20);
		//fade(document.getElementById(itemNumber+"dropIconR"), fade_speed, 0, 100);
	}

	function hilight_left(itemNumber){
		var elem = document.getElementById(itemNumber + "link");
		if(ieorff=="FF"){
			elem2 = document.getElementById(itemNumber + "dropIcon");
		} else {
			elem2 = document.getElementById(itemNumber + "dropDiv");
		}
		elem.style.backgroundColor = "#0132C9";
		elem.style.color = "white";

		if(leftObjType[itemNumber] == "share" || leftObjType[itemNumber] == "directory"){
			//alert('1');
			scoot(elem, 1, 20);
			fade(elem2, fade_speed, 0, 100);
			//alert('2');
		}
	}

	function dehilight_left(itemNumber){
		var elem = document.getElementById(itemNumber + "link");
		elem.style.backgroundColor = "white";
		elem.style.color = "black";
		if(leftObjType[itemNumber] == "share" || leftObjType[itemNumber] == "directory"){
			scoot(elem, 0, 20);
			if(ieorff=="FF")
				fade(document.getElementById(itemNumber + "dropIcon"), fade_speed, 100, 0);
			else
				fade(document.getElementById(itemNumber + "dropDiv"), fade_speed, 100, 0);
		}
	}


	function foundEarlier(num, kill){
		var counter = selectedItems.length;
		for(f_it = 0; f_it < counter; f_it++){
			if(selectedItems[f_it] == num){
				if(kill)
					selectedItems.splice(f_it,1);
				return true;
			}
		}
		return false;
	}

	function areaClick(e){
		var evt = getEvent(e);
		var name = evt.target.id;

		var closelok = false;
		var closerok = false;

		//alert('name');

		//alert(rightClkMenu.style.display + ' - ' + name);

		if(name == 'left' || name=='right'){
			if(rightClkMenu.style.display != 'none'){
				//alert('doesnt equal none');
				rightClkMenu.style.display = 'none';
			}
			if(rightClkMenu2.style.display != 'none'){
				//alert('doesnt equal none 2');
				rightClkMenu2.style.display = 'none';
			}
		}


		var re = new RegExp("[0-9]*textDiv");
		var re2 = new RegExp("[0-9]*dropIconR");
		var re4 = new RegExp("[0-9]*[dropDiv](0,1)[dropIcon](0|1)");
		var re5 = new RegExp("[0-9]*leftItemContainer");
		var re6 = new RegExp("[0-9]*wrapperLeft");
		var re7 = new RegExp("[0-9]*wrapperRight");
		var re8 = new RegExp("[0-9]*rightItem");

		if(name.match(re2)){
			callRightMenu(e);
			//alert('matched re2');
			offLeft();
		} else if (name.match(re)) {
			var right = false;
			if(e.button == 2)
				right = true;
			itemSelect(parseInt(evt.target.id), e.ctrlKey, e.shiftKey, right);	
			//alert('matched re');
			offLeft();
			offRight();
		} else if(name == 'upload'){
			//alert('is upload');
		} else if(name == 'download'){
			//alert('is download');
		} else if(name == 'delete'){
			//delete
		} else if(name.match(re4)){
			//alert('Matched re4');
			offRight();
		} else if (name.match(re5) || name.match(re6) || name.match(re7)){
			offLeft();
			offRight();
		} else if(rightClkMenu.style.display == 'block' && name.match(re8)){
			offLeft();
			if(!blockAreaClick)
				unselectSelected();
		} else if(!blockAreaClick) {
			unselectSelected();
			//alert('unselect');
			offRight();
		}

		blockAreaClick = false;
		
		//alert(name);
		//alert('finished with areaClick');
		//alert('unblocked');
	}

	function offRight(){
		if(rightClkMenu2.style.display != 'none'){
			//alert('doesnt equal none');
			rightClkMenu2.style.display = 'none';
		}
	}

	function offLeft(){
		if(rightClkMenu.style.display != 'none'){
			//alert('doesnt equal none');
			rightClkMenu.style.display = 'none';
		}
	}
/*
	function areaClick(e){
		var evt = getEvent(e);
		if(!((e.ctrlKey && OSName != 'MacOS')||(e.shiftKey)||(blockAreaClick))&&selectedItems.length<=1){
			unselectSelected();
		}
		
		if(rightClkMenu.style.display != 'none' && e.button != 2)
			rightClkMenu.style.display = 'none';
		
		blockAreaClick = false;
		//alert('unblocked');
	}
*/	
	function deselectGroup(e){
		//alert('ding');
		if(!((e.ctrlKey && OSName != 'MacOS')||(e.shiftKey)||(blockAreaClick))){
			unselectSelected();
		}
		//xRemoveEventListener(rightSide, 'mouseup', deselectGroup, true);
		removeEvent('mouseup', deselectGroup, rightSide);
	}

	function executeShiftSelect(number){
		var selectStart = '';	//we sill set these variables in the if statements,
		var selectEnd = '';		//then conduct the opperation in one spot, instead
		var deleteStart = '';	//of inflating the code by giving each one it's own
		var deleteEnd = '';		//codeblock
		if(typeof(shiftPivot)=='number' && shiftPivot >= 0){
			if(typeof(shiftPrevious)!='number' || shiftPrevious < 0){
				if(number > shiftPivot){
					selectStart = shiftPivot+1;
					selectEnd = number;
				} else if (number < shiftPivot){
					selectStart = number;
					selectEnd = shiftPivot-1;
				}

			} else if(number > shiftPrevious){
				if(number > shiftPivot && shiftPivot >= shiftPrevious){
					deleteStart = shiftPrevious;
					deleteEnd = shiftPivot-1;
					selectStart = shiftPivot+1;
					selectEnd = number;
				} else if(number > shiftPivot && shiftPivot < shiftPrevious){
					selectStart = shiftPrevious+1;
					selectEnd = number;
				} else if(number < shiftPivot && shiftPivot > shiftPrevious) {
					deleteStart = shiftPrevious;
					deleteEnd = number-1;
				} else if(number < shiftPivot && shiftPivot < shiftPrevious){
					//error - not sure how to handle it.  Should never happen
					//this is a contradiction
				} else if(number == shiftPivot){
					deleteStart = shiftPrevious;
					deleteEnd = shiftPivot-1;
				} 
			} else if(number < shiftPrevious){
				if(number > shiftPivot && shiftPivot > shiftPrevious){
					//error - not sure how to handle it.  Should never happen
					//this is a contradiction					
				} else if(number > shiftPivot && shiftPivot < shiftPrevious){
					deleteStart = number+1;
					deleteEnd = shiftPrevious;
				} else if(number < shiftPivot && shiftPivot >= shiftPrevious) {
					selectStart = number;
					selectEnd = shiftPrevious-1;
				} else if(number < shiftPivot && shiftPivot < shiftPrevious){
					deleteStart = shiftPivot+1;
					deleteEnd = shiftPrevious;
					selectStart = number;
					selectEnd = shiftPivot-1;
				} else if(number == shiftPivot){
					deleteStart = shiftPivot+1;
					deleteEnd=shiftPrevious;
				}
			}
			//first we delete the selected items that we no longer will highlight
			//from our array
			if(typeof(deleteStart)=='number' && typeof(deleteEnd)=='number'){
				for(j=deleteStart; j <= deleteEnd; j++){
					for(k = 0, ourLen = selectedItems.length; k < ourLen; k++){
						if(selectedItems[k] == j){
							selectedItems.splice(k, 1);
							break;
						}
					}
					dehilight(j);

				}
			}
			//then we will select any new items
			//alert(selectStart + " - " + selectEnd);
			if(typeof(selectStart) == 'number' && typeof(selectEnd) == 'number'){
				for(i=selectStart; i <= selectEnd; i++){	
					if(document.getElementById(i+'listItem').style.display != 'none'){
						if(!foundEarlier(i, false)){ //it's possible that one of the items we are going to select
							selectedItems.push(i);		  //has already been selected.  So we should double check so we
														  //don't end up with 2 of the same ID in our list
							hilight(i);

						}//end !foundEarlier
					}//end != none
				}//end for
			}//end typeof
			shiftPrevious = number;
		} else {
			selectedItems.push(number);	
//			hilight(number);
			shiftPivot = number;
		}
		/*
		//for debugging purposes
		for(looper = 0; looper < selectedItems.length; looper++)
			alert(selectedItems[looper]);
		*/
	}

	function startDrag(textValue, theNumber){
		dragTextValue = textValue;
		doingDrag = true;
		//var evt = getEvent(e);

		if(ieorff=='IE'){
			dragContent.innerText = textValue;
		} else {
			var ourText = document.createTextNode(textValue);
			dragContent.appendChild(ourText);
		}
		/*
		if(evt.target.attachEvent){
			dragMe.style.top = (evt.clientY -10) + 'px';
			dragMe.style.left = (evt.clientX  +2)+ 'px';
		} else {
			dragMe.style.top = (evt.pageY -10) + 'px';
			dragMe.style.left = (evt.pageX +2)+ 'px';
		}
		*/
		//dragMe.style.top = (why -10) + 'px';
		//dragMe.style.left = (ex  +2)+ 'px';
		//xAddEventListener(window, 'mousemove', whileDrag, true);
		//xAddEventListener(document.body, 'mousemove', whileDrag, true);
		addEvent('mousemove',whileDrag,document.body);
		//xAddEventListener(rightSide, 'mousemove', whileDrag, true);
		//xAddEventListener(document.body, 'mouseup', endDrag, false);
		addEvent('mouseup',endDrag,document.body);
		//var theNumber = parseInt(evt.target.id);
		var ourElemToUse = document.getElementById(theNumber + 'rightItem');
		//alert(ourElemToUse.id);
		//alert(ourElemToUse.myLocation);
	}

	function whileDrag(e){
		var evt = getEvent(e);
		//maybe this will cause a small performance issue?
		//not noticable - PMW1302
		
		if(dragMe.style.display=='none'||dragMe.style.display=='')
			dragMe.style.display='inline';
		
		//reposition the div to where we currently are
		if(evt.target.attachEvent){
			dragMe.style.top = (evt.clientY -10) + 'px';
			dragMe.style.left = (evt.clientX  +2)+ 'px';
		} else {
			dragMe.style.top = (evt.pageY -10) + 'px';
			dragMe.style.left = (evt.pageX +2)+ 'px';
		}
	}

	function endDrag(e){

		//deactivate the listeners we created
		//xAddEventListener(window, 'mousemove', whileDrag, true);
		//xRemoveEventListener(document.body, 'mousemove', whileDrag, true);
		removeEvent('mousemove',whileDrag,document.body);
		//xAddEventListener(rightSide, 'mousemove', whileDrag, true);
		//xRemoveEventListener(document.body, 'mouseup', endDrag, false);
		removeEvent('mouseup',endDrag,document.body);
		if(dragContent.lastChild != null)
			dragContent.removeChild(dragContent.lastChild);  //get rid of it's text
		dragMe.style.display = 'none'; //make it dissapear!
		doingDrag = false;
		var evt = getEvent(e);
//alert(evt.target);
          if(typeof(evt.target.id)=='undefined'){
				evt.target.id=evt.target.parentNode.id;
		  }

		if(evt.target.id.indexOf("link") != -1 || evt.target.id.indexOf("iconIcon") !=- 1){
			unclickOverLeft(parseInt(evt.target.id));
		}
	}

	function itemUnclick(e){
		//don't think I need this *shrug*
	}

	//function unclickOverLeft()
	//This function triggers on mouseup on the left-hand side.
	//When we are dragging elements over to the left, this detects the mouse-up and will
	//call the ajax functions needed to move the files
	function unclickOverLeft(objNumber){
		//do_handleFileMove(fileName, destinationShare, destinationDir, rightLocation, rightDirectory, currentWorkgroup);
		do_handleFileMove(objNumber);

		if(OSName == "MacOS" && e.ctrlKey){
			endWait();
			if(rightClkMenu2.style.display != 'none')
				rightClkMenu2.style.display = 'none';
		}
	}

	//function unselectAll()
	//Will toggle each right-hand element to unselected
	//This will take a noticable amount of time when you have a large list, especially in IE
	function unselectAll(){
		var counter = rightItemCount;
		for(ri_it = 0; ri_it < counter; ri_it++){;
			document.getElementById(ri_it + 'textDiv').className='rightItem';
			document.getElementById(ri_it + 'textDiv').className = 'rightItem';
		}
	}

	function unselectSelected(){
		shiftPivot = 'a';
		shiftPrevious = 'a';
		var counter = selectedItems.length;
		for(ri_it = 0; ri_it < counter; ri_it++){
			if(typeof(selectedItems[ri_it])=='number'){
				dehilight(selectedItems[ri_it]);
			}
		}
		selectedItems = new Array();
	}

	function callRightMenu(e){
		if(selectedItems.length > 1)
			changeText(document.getElementById("download"),"Create Zip");
		else
			changeText(document.getElementById("download"),"Download");

		var evt = getEvent(e);
		var itemNumber = parseInt(evt.target.id);
		if(rightClkMenu.style.display != 'none')
			rightClkMenu.style.display = 'none';
		if(evt.target.attachEvent){
			rightClkMenu2.style.top = (evt.clientY) + 'px';
			rightClkMenu2.style.left = (evt.clientX)+ 'px';
		} else {
			rightClkMenu2.style.top = (evt.pageY) + 'px';
			rightClkMenu2.style.left = (evt.pageX) + 'px';
		}
		rightClkMenu2.itemNumber = itemNumber;
		rightClkMenu2.style.display='block';
	}

	function callLeftMenu(e){
		var evt = getEvent(e);
		if(evt.target.nodeType==3) //for mac/safari
			evt.target = evt.target.parentNode;
		var objNumber = parseInt(evt.target.id);
		if(evt.target.attachEvent){
			rightClkMenu.style.top = (evt.clientY) + 'px';
			rightClkMenu.style.left = (evt.clientX)+ 'px';
		} else {
			rightClkMenu.style.top = (evt.pageY) + 'px';
			rightClkMenu.style.left = (evt.pageX) + 'px';
		}
		rightClkMenu.style.display='block';
		if(rightClkMenu2.style.display != 'none')
			rightClkMenu2.style.display = 'none';
		//Setup data
		rightClkMenu.myLocation = leftLocation[objNumber];
		rightClkMenu.myWorkgroup = leftWorkgroup[objNumber];
		rightClkMenu.myDirectory = leftDirectory[objNumber];
	}

	//function setToWindow()
	//When the browser is first loaded or when the window is resized setToWindow will adjust the height and width of the
	//browser so that it takes up the maximum amount of space.  It was nessessary to set the width and height
	//of the browser due to the complicated nested divs with their properties.
	function setToWindow(e){
		//bad default sizes, I know.  Shouldn't matter, though.

		var sizeMe = 10;
		var sizeMe2 = 10;
		var topBarSize = 30; // adjust this as needed
		
		//Using object detection, we get the height and width of the window.
		//on the height, the -20 is used because when programming this I had a single line of text
		//above the browser window.  YOU MUST ADJUST THIS TO THE HEIGHT OF WHATEVER IS IN THE 
		//CONTENT ABOVE THE BROWSER WINDOW - I'll fix that later
		//on the width, the -250/-255 is the adjustment for the server/directory listing on the left.
		//The reason why there are two different values is because IE was being a brat and needed the extra
		//5px to work.
		//alert(topBarSize);

		//topBarSize = document.getElementById('topBar').innerHeight;
		if(typeof(window.innerHeight)=='number'){ //Netscape/Mozilla
			sizeMe2 = window.innerHeight -52;
			sizeMe = window.innerWidth - leftWidth -10;
			//topBarSize = document.getElementById('topBar').innerHeight;
		} else if(document.documentElement&&document.documentElement.clientHeight){ //IE
			sizeMe = document.documentElement.clientWidth - (leftWidth + 9);
			sizeMe2 = document.documentElement.clientHeight -52;
			//topBarSize = document.getElementById('topBar').style.height;
		} else if(document.body&&document.body.clientHeight){ //Don't know who, we just need it
			sizeMe2 = document.body.clientHeight -52;
			sizeMe = document.body.clientWidth - (leftWidth + 9);
		}
		leftSide.style.width = leftWidth + 'px';
		rightSide.style.width = sizeMe + 'px';
		leftSide.style.height = sizeMe2 + 'px';
		rightSide.style.height= sizeMe2 + 'px';
		mover.style.height = sizeMe2 + 'px';
mover.style.width = '4' + 'px';
		moveBar.style.height=sizeMe2 + 'px';
		moveBar.style.top=topBarSize + 1 + 'px';
		loadingDiv.style.left = (leftWidth+6)  + 'px';
		loadingDiv.style.top = topBarSize + 'px';
	}

	function moveBorder(e){
		var evt = getEvent(e);
		document.body.style.cursor = 'move';		
		//reposition moveBar;
		moveBar.style.display='block';
		if(evt.target.attachEvent){
			moveBar.style.left = (evt.clientX -1)+ 'px';
		} else {
			moveBar.style.left = (evt.pageX -1)+ 'px';
		}
		
		//donno why I have to list each one instead of window.body - mabye because of the ondrag?
/*
		xAddEventListener(rightSide, 'mousemove', moveTheBar, true);
		xAddEventListener(rightSide, 'mouseup', stopMoveBar, true);
		xAddEventListener(leftSide, 'mousemove', moveTheBar, true);
		xAddEventListener(leftSide, 'mouseup', stopMoveBar, true);
		xAddEventListener(mover, 'mousemove', moveTheBar, true);
		xAddEventListener(mover, 'mouseup', stopMoveBar, true);
		xAddEventListener(moveBar, 'mouseup', stopMoveBar, true);
*/
		addEvent('mousemove', moveTheBar, rightSide);
		addEvent('mouseup', stopMoveBar, rightSide);
		addEvent('mousemove', moveTheBar, leftSide);
		addEvent('mouseup', stopMoveBar, leftSide);
		addEvent('mousemove', moveTheBar, mover);
		addEvent('mouseup', stopMoveBar, mover);
		addEvent('mouseup', stopMoveBar, moveBar);
	}

	function loadingOn(numHere){
		//alert("Up: "+loadingDiv.style.display);
		beginWait();
		loadingDiv.style.display = "block";
		loadingDiv.style.visibility='visible';
		changeText(waitingText,"Working");
		waitingDiv.style.display = "block";

	}

	function loadingOff(numHere){
		endWait();
		//alert("Down: "+loadingDiv.style.display);
		loadingDiv.style.display = "none";
		loadingDiv.style.visibility='hidden';
		waitingDiv.style.display = "none";
	}

	function changeText(element, msg){
		if(ieorff=="IE"){
			element.innerText = msg;
		} else {
			while(element.firstChild != null)
				element.removeChild(element.firstChild);
			element.appendChild(document.createTextNode(msg));
		}
	}

	function changeLink(element, msg, url){
		//the download link
		var ourAnchor = document.createElement("a");
		ourAnchor.href = "javascript:redirectHere('"+url+"');";
		ourAnchor.style.textDecoration="none";
		//the info link
		var ourAnchor2 = document.createElement('a');
		ourAnchor2.href = "javascript:zipInfo();";
		ourAnchor2.style.textDecoration="none";
		//ourAnchor2.style.textDecoration="none";
		var ourImage = document.createElement('img');
		ourImage.src = "./images/info_16.png";
		ourImage.style.border="solid 0px white";
		ourImage.style.padding="2px 0px 2px 2px";
		//the kill link
		var ourAnchor3 = document.createElement('a');
		ourAnchor3.href = "javascript:killZipFile();";
		ourAnchor3.style.textDecoration="none";
		var ourImage2 = document.createElement('img');
		ourImage2.src = "./images/button_cancel_16.png";
		ourImage2.style.border="solid 0px white";
		ourImage2.style.padding="4px 0px 1px 2px";

		if(ieorff=="IE"){
			ourAnchor.innerText = msg;
		} else {
			ourAnchor.appendChild(document.createTextNode(msg));
		}
		while(element.firstChild != null){
			element.removeChild(element.firstChild);
		}
		ourAnchor2.appendChild(ourImage);
		ourAnchor3.appendChild(ourImage2);
		element.appendChild(ourAnchor);
		element.appendChild(ourAnchor2);
		element.appendChild(ourAnchor3);
	}

	function moveTheBar(e){
		document.body.style.cursor = 'move';
		var evt = getEvent(e);
		moveBar.style.display='block';
		if(evt.target.attachEvent){
			moveBar.style.left = (evt.clientX  -1)+ 'px';
		} else {
			moveBar.style.left = (evt.pageX -1)+ 'px';
		}
	}

	function stopMoveBar(e){
		var evt = getEvent(e);
/*
		xRemoveEventListener(rightSide, 'mousemove', moveTheBar, true);
		xRemoveEventListener(rightSide, 'mouseup', stopMoveBar, true);
		xRemoveEventListener(leftSide, 'mousemove', moveTheBar, true);
		xRemoveEventListener(leftSide, 'mouseup', stopMoveBar, true);
		xRemoveEventListener(mover, 'mousemove', moveTheBar, true);
		xRemoveEventListener(mover, 'mouseup', stopMoveBar, true);
		xRemoveEventListener(moveBar, 'mouseup', stopMoveBar, true);
*/
		removeEvent('mousemove', moveTheBar, rightSide);
		removeEvent('mouseup', stopMoveBar, rightSide);
		removeEvent('mousemove', moveTheBar, leftSide);
		removeEvent('mouseup', stopMoveBar, leftSide);
		removeEvent('mousemove', moveTheBar, mover);
		removeEvent('mouseup', stopMoveBar, mover);
		removeEvent('mouseup', stopMoveBar, moveBar);

		moveBar.style.display='none';
		document.body.style.cursor = 'default';
		//set position of the divider
		if(evt.target.attachEvent){
			moveBar.style.left = (evt.clientX  -2)+ 'px';
			leftWidth = parseInt(moveBar.style.left) + 0;
		} else {
			moveBar.style.left = (evt.pageX -1)+ 'px';
			leftWidth = parseInt(moveBar.style.left) - 2;
		}
		
		e = '';
		setToWindow(e);
	}

	function resizeArea(){
		//waste
	}

	function onBarOver(e){
		document.body.style.cursor = 'move';
	}

	function onBarOut(e){
		document.body.style.cursor = 'default';
	}

	//function postError()
	//postError will display network errors in the right-hand side of the browser
	function postError(errMsg){
		alert(errMsg);
	}

/*
	//Functions for the right-click menu (right click menu)
	function callRightMenu(e){
		var evt = getEvent();
		if(e.button == 2){ //just making sure - donno why
			rightClkMenu.style.display='block';
			if(evt.attachEvent){
				//alert(evt.clientY);
				rightClkMenu.style.top = (evt.clientY) + 'px';
				rightClkMenu.style.left = (evt.clientX)+ 'px';
			} else {
				//alert(evt.pageY);
				rightClkMenu.style.top = (evt.pageY) + 'px';
				rightClkMenu.style.left = (evt.pageX) + 'px';
			}			
		}
	}
*/



	function triggerUpload(e){
		endWait();
		x_triggerUpload(username, password, rightClkMenu.myWorkgroup, rightClkMenu.myLocation, rightClkMenu.myDirectory, do_triggerUpload_cb);	
	}

    var popWindowObj='';
    
	function do_triggerUpload_cb(z){

		eval("window.passed = " + z);	

		if(window.passed['error'] == 'error'){
			postError(window.passed['msg']);
		} else {
			var url = "./uploadFile.php?enc_param="+window.passed['path'];
			window_make_new(-1, -1, 650, 250, url,"SSLBridge - Upload");
			//dWindow(url,650,250,10,50);
			//window.open(url,"SSLBridge - Upload File","location=0,status=0,scrollbars=0,width=650,height=250");
		}
		rightClkMenu.style.display='none';
	}

	//Not needed (yet) so it's commented out
	/*
	function do_deleteFolder(e){
		x_deleteFolder(username, password, rightClkMenu.myWorkgroup, rightClkMenu.myLocation, rightClkMenu.myDirectory, do_deleteFolder_cb);	
	}

	function do_deleteFolder_cb(z){
		eval("window.passed = " + z);	

		if(window.passed['error'] == 'error'){ //Error catcher
			postError(window.passed['msg']);
		} else {

		}
		rightClkMenu.style.display='none';
	}
	*/

	//function do_deleteFile
	function do_deleteFile(e){
		rightClkMenu.style.display='none';  //eh, might as well
		rightClkMenu2.style.display='none';
		if(selectedItems.length > 1){ //I'll make sure to allow this in a future release, but for now 
									  //one file at a time is fine
			alert('You cannot delete multiple files at one time.  Please delete each file individually');
			return;
		} else { 
			var fileName = document.getElementById(selectedItems[selectedItems.length-1] +'textDiv').innerHTML;
			if(confirm("Delete file "+fileName+"?")){
				beginWait();
				x_deleteFile(username, password, lastWorkgroup, rightLocation, rightDirectory, fileName, do_deleteFile_cb);	
			}//end if(confirm("Delete file "+fileName+"?"))
		}//end if(selectedItems.length > 1)
	}//end function do_deleteFile(e)

	//function do_deleteFile_cb
	function do_deleteFile_cb(z){
		eval("window.passed = " + z);	

		if(!checkError(window.passed)){
			//remove the file from view
			changeStatusBar('File Deleted: ' + window.passed['filename']);
			document.getElementById(selectedItems[0]+'listItem').style.display='none';			
		}
		endWait();

		/*
		if(window.passed['error'] == 'error'){ //Error catcher
			postError(window.passed['msg']);
			changeStatusBar(window.passed['msg']);
		} else { //remove the file from the user's sight
			changeStatusBar('File Deleted: ' + window.passed['filename']);
		}//end if(window.passed['error'] == 'error')
		rightClkMenu.style.display='none';
		rightClkMenu2.style.display='none';
		endWait();
		*/
	}//end function do_deleteFile_cb(z)

	//function checkError
	//given the eval'd data passed back from a SAJAX call, it will
	//do the processing needed to check for errors
	//Since every callback does this, I figured a function was the
	//natural progression of things
	function checkError(ourArray){
		var returnMe = false;

		if(ourArray['error'] == 'error'){
			postError(ourArray['msg']);
			changeStatusBar(ourArray['msg']);
			returnMe = true;
		} else {
			returnMe = false;
		}//end if(ourArray['error'] == 'error')

		return returnMe;
	}//end function checkError(ourArray)

	function changeStatusBar(txt){
		if(ieorff=='IE'){
			statusBar.innerText = txt;
		} else {
			if(statusBar.lastChild != null)
				statusBar.removeChild(statusBar.lastChild);
			var textPlace = document.createTextNode(txt);
			var newDiv = document.createElement('div');
			newDiv.appendChild(textPlace);
			statusBar.appendChild(newDiv);
		}
	}

	function catchKeyPress(e){
		var evt = getEvent(e);
		var keyValue = ((ieorff=='IE')?e.keyCode:e.which);
		if(e.ctrlKey){
			if(keyValue == 67){ //'C' key
				//alert('copy');
				copyLocation = '';
				copyWorkgroup = '';
				copyDirectory = '';
				copyItems = new Array();
				//get the location and workgroup
				if(selectedItems.length>=1){
					var ourElem = document.getElementById(selectedItems[0] + "rightItem");
					copyLocation = rightLocation;
					copyDirectory = rightDirectory;
					copyWorkgroup = lastWorkgroup;
					//for each item selected
					//     get it's name
					for(i = 0, ourLen = selectedItems.length; i < ourLen; i++){
						copyItems.push(document.getElementById(selectedItems[i] + "textDiv").innerHTML);
					}
					//alert(copyItems.length + " items from "+copyLocation+" "+copyDirectory);
				}
			}else if (keyValue == 86){ //'V' key
				var objNumber = parseInt(selectedFolder.id);

				var dShare = leftLocation[objNumber];
				var dDir = leftDirectory[objNumber];

				inQueue = copyItems.length;
				changeText(waitingText,"Moving");
				waitingDiv.style.display="block";
				for(i = 0, ourLen = copyItems.length; i < ourLen; i++){
					x_handleFileMove('copy',copyItems[i], username, password, dShare, dDir, copyLocation, copyDirectory, copyWorkgroup, do_handleFileMove_cb2);
				}
				//do_handleFileMove(fileName, destinationShare, destinationDir, sourceShare, sourceDir, wg);
				//x_handleFileMove(fName, username, password, dShare, dDir, sShare, sDir, workgroup, do_handleFileMove_cb);

				//since the files are just being copies, this shouldn't need done, I'd think...
				/*
				copyLocation = '';
				copyWorkgroup = '';
				copyDirectory = '';
				copyItems = new Array();
				*/
			} else {
				//don't do anything as of  yet - right now we don't care
			}
		}
	}

	function do_handleFileMove_cb2(z){
		//alert(z);

		eval("window.passed = " + z);	
		if(window.passed['error'] == 'error'){ //Error catcher
			inQueue--;
			if(!errorOff){
				postError(window.passed['msg']);			
				errorOff=true;
			}
		} else if(window.passed['size']!=''){
			inQueue--;
			createRightItem(window.passed['name'],window.passed['size'],window.passed['wday'],window.passed['month'],window.passed['day'],window.passed['time'],window.passed['year'],'./ukn.gif');		
		}

		if(inQueue == 0){
			changeStatusBar("Finished File Copy");
			waitingDiv.style.display="none";
			errorOff = false;
		}
	}

	function activateLink(){
		//nothin'
	}

	//here's a nifty trick I've learned...
	function beginWait(){
		document.documentElement.className='waitCursor';
	}

	function endWait(){
		document.documentElement.className='';
	}
	//ain't that slick?  

	function redirectHere(url){
 //alert(document.getElementById("hiddenFrame").src);
          if(OSName=='MacOS'){
 		    window.document.location.href = url;
          } else {
			document.getElementById("hiddenFrame").src = url;
		  }  
	}

	//function init()
	//This function is called on start-up of the browser.  It will set initial variables, query for the
	//workgroups, and activate all start-up functions and listeners
	function init(e){
		whereTo = 'left';
		whatToExpect = 'workgroups';
		smbCommand = 1;
		rightSide = document.getElementById('right');
		leftSide = document.getElementById('left');
		mover = document.getElementById('mover');
		moveBar = document.getElementById('moveBar');
		dragMe = document.getElementById('theDragger');
		dragContent = document.getElementById('dragWrap');
		loadingDiv = document.getElementById('loadingDiv');
		rightClkMenu = document.getElementById('rightClkMenu');
		rightClkMenu2 = document.getElementById('rightClkMenu2');
		statusBar = document.getElementById('statusBar');
		waitingDiv = document.getElementById('waitingDiv');
		waitingText = document.getElementById('waitingText');
		messageDiv = document.getElementById('messageDiv');
		messageText = document.getElementById('messageText');
		loadingOn(1);

		rightSideC = document.createElement('ul');
		rightSideC.className = 'rightSideList';
		rightSide.appendChild(rightSideC);
		do_handleRequest('no', 'localhost', smbCommand, '', '');

		setToWindow();

		if(rightSide.attachEvent)
			ieorff = 'IE';
		else
			ieorff = 'FF';

		/*
		//horrible hack that didn't even work anyway
		if(rightSide.attachEvent){
			if(navigator.userAgent.indexOf("MSIE 7.")!=-1){
				ieorff = 'FF';
			} else 
				ieorff = 'IE';
		}else
			ieorff = 'FF';
		*/


			rightTemplate = document.createElement('div'); //holder
			rightTemplate.appendChild(document.createElement('div')); //floatie
			rightTemplate.childNodes[0].appendChild(document.createElement('div')); //left floaty
			rightTemplate.childNodes[0].appendChild(document.createElement('div')); //right floaty
			if(ieorff == 'IE'){
				rightTemplate.appendChild(document.createElement('div')); //icon
				rightTemplate.appendChild(document.createElement('div')); //drop box
			} else {
				rightTemplate.appendChild(document.createElement('img')); //icon
				rightTemplate.appendChild(document.createElement('img')); //drop box
			}
			rightTemplate.appendChild(document.createElement('div'));  //text node
/*
		xAddEventListener(rightSide, 'mousedown', areaClick, true);
		xAddEventListener(mover, 'mousedown', moveBorder, true);
		xAddEventListener(mover, 'mouseover', onBarOver, true);
		xAddEventListener(mover, 'mouseout', onBarOut, true);
*/
		if(window.attachEvent)
			addEvent('mousedown', areaClick, document.body);
		else
			addEvent('mousedown', areaClick, window);
		addEvent('mousedown', moveBorder, mover);
		addEvent('mouseover', onBarOver, mover);
		addEvent('mouseout', onBarOut, mover);

		//For right-click menu.  Might need it's own init elsewhere, but 
		//for now this is cool
		//xAddEventListener(document.getElementById('upload'), 'click', triggerUpload, true);
		//xAddEventListener(document.getElementById('download'),'click', do_downloadFile, true);

		addEvent('click', triggerUpload, document.getElementById('upload'));
		addEvent('click', do_downloadFile, document.getElementById('download'));
		addEvent('click', do_deleteFile, document.getElementById('delete'));

		if(ieorff == 'IE'){
			//xAddEventListener(document.body, 'keydown', catchKeyPress, true);
			addEvent('keydown', catchKeyPress, document.body);
		} else {
			//xAddEventListener(window, 'keydown', catchKeyPress, true);
			addEvent('keydown', catchKeyPress, window);
		}

		document.body.ondrag = function () { return false; };
		document.body.onselectstart = function () { return false; };
		if(ieorff=='IE')
			window_configuration('#005547', 2, 'white','#005547','white','');	//there is something in SSLBridge that makes 
		else																//PNG support for the windows break  *shrug*
			window_configuration('#005547', 2, 'white','#005547','white','./images/button_cancel.png');

		initOverlay("white");
	}

	//function shutDown()
	//This will be called when the window is closed or refreshed.  It will remove all of the listeners from
	//all objects on the screen, ensuring a clean transfer
	function shutDown(e){
		//remove all action listeners from the right
		//clearRight('yesplease'); //I know it removes all of the divs, too, but since it removes all of the listeners
								 //anyway...
		//remove all action listeners from the left
		//remove all action listeners from the window
/*
		xRemoveEventListener(window, 'load', init, false);
		xRemoveEventListener(window, 'resize', setToWindow, false);
		xRemoveEventListener(window, 'unload', shutDown, false);
		xRemoveEventListener(rightSide, 'mousedown', areaClick, true);
		xRemoveEventListener(mover, 'mousedown', moveBorder, true);
		xRemoveEventListener(mover, 'mouseover', onBarOver, true);
		xRemoveEventListener(mover, 'mouseout', onBarOut, true);
*/
		removeEvent('load', init, window);
		removeEvent('resize', setToWindow, window);
		removeEvent('unload', shutDown, window);
		removeEvent('mousedown', areaClick,window);
		removeEvent('mousedown', moveBorder, mover);
		removeEvent('mouseover', onBarOver, mover);
		removeEvent('mouseout', onBarOut, mover);
		if(zipMade)
			x_killZipFile(zipEnc, do_killZipFile_cb);
	
	}
	//Event Listeners for the Window
	addEvent('load',init, window); 
	addEvent('resize', setToWindow, window);
	addEvent('unload', shutDown, window);