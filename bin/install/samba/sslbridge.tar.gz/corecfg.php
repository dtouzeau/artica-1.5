<?php

	define("USESESSION", "true");
	define("DEMOMODE", "false");			//If this is ture, disables upload and gives demo message
	define("DEMOMODEU", "false");
	define("NOTIMEOUT", "true");			//Removes the time when cookies die.
	define("PORTAL",'false');				//If ture, requires the Epiware cookie to be set
	define("UPLOADLIMIT", '68719476736');	//around 70gig

	define("WORKINGDIR", 'sslbridge');		//The directory all SSLBridge work will occur in
	//define("USE_MOUNT", 'true');			//If this is true, it doesn't sue Samba; uses mount/umount instead
	define("64_ENCODE",'true');

	define("DEBUG", "true");				//For developers 
	define("DEBUGFILE", 'lookHere.txt');	//Filename that all debug info gets dumpped to
	define("DEBUGPATH", '/tmp/');			//Path must be from root, and include the ending slash

	//unfinished features
	define("PAGEDRESULTS", 'false');		//If true, will limit how many files it will display to user at once
	define("PAGELIMIT", '0');				//If PAGEDRESULTS is ture, this is how many files it will do at once
											//Zero (0) will be counted as PAGEDRESULTS = false

	if(USESESSION == 'true')
		session_start();
?>
