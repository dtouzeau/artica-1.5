<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
	require_once('./json.php');
	//function errorHandler()
	//Given a string, usually what is returned from smbclient calls, it will use a RE to
	//see if an error has been thrown.  The format that an error is in will be the following:
	//		$returnMe = array();
	//		$returnMe['error'] = 'error';
	//		$returnMe['msg'] = $errorMessages[$errorNo];
	//		$sendMe = $json->encode($returnMe);
	// otherwise it will return false
	function errorHandler($result){
		//to check for errors, we should put an array of possible error REs here
		$errorLines = array();
		$errorMessages = array();
		$errorLines[] = "(.*)NT_STATUS_LOGON_FAILURE(.*)\$";
		$errorMessages[] = "Could not authenticate user on the network you are accessing.";
		$errorLines[] = "(.*)NT_STATUS_CANNOT_DELETE(.*)\$";
		$errorMessages[] = "The folder you have selected can not be deleted by you.";
		$errorLines[] = "(.*)NT_STATUS_NETWORK_ACCESS_DENIED(.*)\$";
		$errorMessages[] = "You do not have access to this part of the network.";
		$errorLines[] = "(.*): NT_STATUS_ACCESS_DENIED(.*)\$";
		$errorMessages[] = "You do not have access to the directory you are trying to access.";
		$errorLines[] = "(.*)NT_STATUS_BAD_NETWORK_NAME(.*)\$";
		$errorMessages[] = "The name for the network being used is incorrect.";
		$errorLines[] = "(.*): Permission denied(.*)\$";
		$errorMessages[] = "You do not have access to the destination folder or file.";
		$errorLines[] = "(.*)ERRnosuchshare(.*)\$";
		$errorMessages[] = "The a share you are trying to access can not be recognized by the network right now.  It may have been removed from the network or can not be located due to the network configuration.";
		$errorLines[] = "(.*)ERRnoaccess(.*)\$";
		$errorMessages[] = "Access has been denied to to the location you are connecting to.";
		$errorLines[] = "(.*)<b>(.*)\$";
		$errorMessages[] = "There is a server-side error: Contact your network administrator.";
		$errorLines[] = "(.*)Anonymous login successful(.*)\$";
		$errorMessages[] = "You have not entered a valid login.  Please return to the login screen and try to authenticate again.  If this error persists contact your network administrator.";
		$errorLines[] = "(.*)Access denied(.*)\$";
		$errorMessages[] = "You do not have permission to access this file.";
		$errorLines[] = "(.*)timeout connecting to(.*)\$";
		$errorMessages[] = "A connection to the server cannot be established.  The server could be down or disconnected from the network.";
		$errorLines[] = "(.*)connectiond(.*)\$";
		$errorMessages[] = "You do not have authorization to access the destionation.";
		$errorLines[] = "(.*)not enough(.*)in service(.*)\$";
		$errorMessages[] = "An error occured while trying to access a part of the network: Wrong Syntax - Not Enough Characters.  Please contact your network administrator.";
		$errorLines[] = "(.*)Connection to (.*) failed\$";
		$errorMessages[] = "The connection has failed.  The connection is not available at this time.";
		$errorLines[] = "(.*)cannot mount on (.*): operation not permitted\$";
		$errorMessages[] = "The a server you are accessing is not properly set up to accept SSLBridge.";
		$errorLines[] = "(.*)NT_STATUS_OBJECT_NAME_NOT_FOUND\$";
		$errorMessages[] = "The location you are trying to access can not be reached by SSLBridge.";

		$json = new Services_JSON();
		$catchMe = explode("\n", $result);

		foreach($catchMe as $key => $item){
			foreach($errorLines as $errorNo => $errorType){
				if(preg_match('/'.$errorType.'/', $item)){
					$returnMe = array();
					$returnMe['error'] = 'error';
					$returnMe['msg'] = $errorMessages[$errorNo];
					$sendMe = $json->encode($returnMe);
					report('ErrorHandler',$errorMessages[$errorNo]);			
					return $sendMe;
				}
			}
		}
		return false;
	}

	//The following are all used for the mounting and unmounting of shares for 
	//purposes of moving files
	//putenv() was used for convienience
	function makeBaseDirectory($username, $password){
		putenv("USER=$username%$password");
		if(!file_exists(SYSTEMDIR.'/'.WORKINGDIR)){
			$cmd = "mkdir ".SYSTEMDIR."/".WORKINGDIR;
			report('Mkdir',$cmd);	
			$result = `$cmd`;
		}
		if(!file_exists(SYSTEMDIR."/".WORKINGDIR."/$username")){
			$cmd = "mkdir ".SYSTEMDIR."/".WORKINGDIR."/$username";
			report('Mkdir',$cmd);
		}
		return `$cmd`;
	}

	//function removeBaseDirectory
	function removeBaseDirectory($username, $password){
		if(file_exists(SYSTEMDIR."/".WORKINGDIR."/$username")){
			$cmd = "rmdir ".SYSTEMDIR."/".WORKINGDIR."/$username";
			report('Rmdir',$cmd);
			$result = `$cmd`;
		}
		if(file_exists(SYSTEMDIR."/".WORKINGDIR)){
			$cmd = "rmdir ".SYSTEMDIR."/".WORKINGDIR;
			report('Rmdir',$cmd);
		}
		return `$cmd`;
	}

	//functionMakeDirectory
	function makeDirectory($name, $username, $password){
		putenv("USER=$username%$password");
		if(!file_exists(SYSTEMDIR.'/'.WORKINGDIR.'/'.$username.'/'.$name)){
			$cmd = 'mkdir '.SYSTEMDIR.'/'.WORKINGDIR.'/'.$username.'/'.$name;
			report('Mkdir',$cmd);
		}
		return `$cmd`;
	}

	//functionMakePath
	function makePath($path){
		if(!defined(SYSTEMDIR))
			define("SYSTEMDIR","/tmp");

		$pathNames = array();
		$pathNames = explode('/',$path);
		$currentPath = '';
		foreach($pathNames as $key=>$name){
			if($name != ''){
				$whatWeGot = $currentPath . $name;
				if($whatWeGot != SYSTEMDIR){
					$cmd = "mkdir $whatWeGot";
					$result = `$cmd`;
				}
				$currentPath = $whatWeGot;
			}
			$currentPath .= '/';
		}
		$currentPath = substr_replace($currentPath,"",-1);

		return $currentPath;
	}

	//function removePath
	function removePath($path){
		if(!defined(SYSTEMDIR))
			define("SYSTEMDIR","/tmp");

		$waitForIt = 20;
		while($path != SYSTEMDIR){
			$cmd = "rmdir $path";
			$result = `$cmd`;
			report('Path', $cmd);

			$lastSlash = strrpos($path, '/');
			$length = strlen($path)-1;
			$value=(-1)*($length-$lastSlash);
			$value--;

			$path=substr_replace($path,'',$value);
			--$waitForIt;
			if($waitForIt <= 0)
				break;
			//$path =  substr_replace($path,'',(((strlen($path)-1) - strrpos($path,'/'))*(-1))-1);
		}		
	}

	//Just makes the directory passed to it
	function makeNormDirectory($name, $username, $password){
		putenv("USER=$username%$password");
		if(!file_exists($name)){
			$cmd = 'mkdir '.$name;
			report('Mkdir',$cmd);
		}
		return `$cmd`;
	}

	//function makeMount
	function makeMount($whereTo, $whereFrom, $workgroup, $username, $password){
		$json = new Services_JSON;
		//putenv("USER=$username%$password");
		//$cmd = "smbmount '$whereFrom' '$whereTo' -o -S";
		$whereTo = str_replace("\\\\", "", $whereTo);
		$whereTo = str_replace (" ", "\ ", $whereTo);
		$whereFrom = str_replace("\\\\", "", $whereFrom);
		$whereFrom = str_replace(" ", "\ ", $whereFrom);
		$password = str_replace('\$','$',$password);

		$holder = explode('/',$whereFrom);
		error_log("SSLBridge: $holder -> {$holder[2]}");
		
		$holder2 = getIP($holder[2]);
		if(!$holder2){
			$error = array();
			$error['error'] = 'error';
			$error['msg'] = 'Could not lookup IP address for server.';
			$whatWeGot = $json->encode($error);
			return $whatWeGot;
		}
		$ip = $holder2;
		$MY_USE_MOUNT=USE_MOUNT;
		if(!is_file("/usr/bin/smbmount")){$MY_USE_MOUNT=true;}
		

		makePath($whereTo);
		if($MY_USE_MOUNT == 'true'){
			// jk wrong format,
			// $cmd = "mount -t cifs $whereFrom $whereTo -o username='$username/$workgroup',password='***',ip=$ip,iocharset=iso8859-15 -S";
            $cmd = "mount -t cifs $whereFrom $whereTo -o username='$username',password='***',ip=$ip,domain=$workgroup 2>&1";
		} else {
			$cmd = "smbmount $whereFrom $whereTo -o username='$username/$workgroup',password='***',ip=$ip,iocharset=iso8859-15 2>&1";
		}//end if(USE_MOUNT == 'true')
		report('Mount',$cmd);
		if($MY_USE_MOUNT == 'true'){
              // jk wrong format
			  //$cmd = "mount -t cifs $whereFrom $whereTo -o username='$username/$workgroup',password='$password',ip=$ip,iocharset=iso8859-15 -S";
              $cmd = "mount -t cifs $whereFrom $whereTo -o username='$username',password='$password',ip=$ip,domain=$workgroup 2>&1";
			  
		} else {
			$cmd = "smbmount $whereFrom $whereTo -o username='$username/$workgroup',password='$password',ip=$ip,iocharset=iso8859-15 2>&1";
		}//end if(USE_MOUNT == 'true')
		$theArray = array();
		$returnIt = '';

 

		$returnMe = exec($cmd, $theArray, $returnIt);
		
		error_log("SSLBridge: $cmd".@implode("\n",$theArray)." ".__FUNCTION__." ".basename(__FILE__)." line:".__LINE__);
		
		//$send = errorHandler($theArray[0])

	//	if(!$send){
			//I don't know why we return what we do...
			//it should not be makePath's job to do the errorHandler!
			$size = sizeof($theArray);
			return "$size - ".$theArray[0] . " - " . $returnIt;
	//	} else {	
	//		return $send;
	//	}//end if(!send)
	}

	//removeMount()
	//removes a mount that is passed to it from the $location var
	function removeMount($location, $username, $password){
		
		$MY_USE_MOUNT=USE_MOUNT;
		if(!is_file("/usr/bin/smbmount")){$MY_USE_MOUNT=true;}		
		
		putenv("USER=$username%$password");
		if($MY_USE_MOUNT == 'true'){
			$cmd = "umount '$location' 2>&1";
		} else {
			$cmd = "smbumount '$location' 2>&1";
		}//end if(USE_MOUNT == 'true')
		report('Unmount',$cmd);
		exec($cmd);
		removePath($location);

		return $cmd;
	}

	//function report()
	//a debug function (finally)
	//It takes 2 parameters.  It's output is like this:
	// param1:(param2)
	function report($title, $msg){
		if(DEBUG == 'true'){
			$fp = fopen(DEBUGPATH . DEBUGFILE,"a");
			fwrite ($fp,"$title:($msg)"."\n");
			fclose($fp);
		}
	}

	//function getIP()
	//Given a network name, it will use nmblookup to return an IP address
	function getIP($name){
		if($name=="localhost"){return "127.0.0.1";}
		if($name=="127.0.0.1"){return "127.0.0.1";}
		report('Nmblookup',"nmblookup $name -B");
		exec("nmblookup $name -B",$data);
		error_log("SSLBridge:: getIP($name) ->  ".@implode($data)."\n".basename(__FILE__)." [".__FUNCTION__."]:".__LINE__);
		$size = sizeof($data);
		for($i = $size; $i > 0; --$i){
			if(strpos($data[$i],'<')!==false){ //Looking for a line
			                                   //like "192.168.1.1 MY_PDC<00>"
				report('nmblookup result',$data[$i]);
				$catch = explode(' ', $data[$i]);
				$ip = $catch[0];				
				$i = 0;
			}//end if(strpos($data[$i],'<')!==false)
		}//end for($i = $size; $i > 0; --$i)
		/*
		report('nmblookup',$data[1]);
		$catch = explode(' ', $data[1]);
		$ip = $catch[0];
		
		if($ip == 'name_query')
			return false;
		else
			return $ip;
		*/
		$re = "/[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}/"; //IP	
		if(preg_match($re, $ip))
			return $ip;
		else
			return false;
	}//end function getIP($name)

	/*
	//Never finished this feature, but could be useful, so leaving it commented out

	//function returnDCArray
	//This will return the domain controllers put into the define LOCALHOST
	function getDCArray(){
		//in this case, it assumes that LOCALHOST is a comma-delimited list of 
		//domain controllers
		$ourArray = explode(',',LOCALHOST));
		for($i = sizeof($ourArray); $i > 0; --$i){
			//just to be tidy
			$ourArray[$i] = trim($ourArray[$i]);
		}//end for($i = sizeof($ourArray); $i > 0; --$i)

		return $ourArray;
	}//end function getDCArray()

	//function getIP_multi()
	//This will run through each domain controller in the LOCALHOST define
	//in order until a valid IP is returned
	//RETURNS AN ARRAY where ['ip'] is the ip 
	//and ['location'] gets put into $location
	function getIP_multi(){
		$dcArray = getDCArray();
		$i = sizeof($dcArray);
		$ip = false;
		while($i > 0 || $ip == false){
			--$i;
			if(!($ip = getIP($dcArray[$i]))){
				$returnArray = false;
			} else {
				$returnArray = array();
				$returnArray['ip'] = $ip;
				$returnArray['location'] = $dcArray[$i];
			}//end if(!($ip = getIP($dcArray[$i])))
		}//end while($i > 0 || $ip == false)

		return $returnArray;
	}//end function getIP_multi()
	*/
?>