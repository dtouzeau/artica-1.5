<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
	function find_gif_name($fileName){
		$ourArray = explode('.', $fileName);
		$length = sizeof($ourArray);

		$end = strtolower($ourArray[$length-1]);

		switch($end)
		 {
		   case ".ai":
			  $icon = "ai.gif";
			  break;
		   case ".avi":
			  $icon = "avi.gif";
			  break;
		   case ".bmp":
			  $icon = "bmp.gif";
			  break;
		   case ".doc":
			  $icon = "doc.gif";
			  break;
		   case ".dwg":
			  $icon = "dwg.gif";
			  break;
		   case ".eps":
			  $icon = "eps.gif";
			  break;
		   case ".fh10":
			  $icon = "fh10.gif";
			  break;
		   case ".fla":
			  $icon = "fla.gif";
			  break;
		   case ".flx":
			  $icon = "flx.gif";
			  break;
		   case ".gif":
			  $icon = "gif.gif";
			  break;
		   case ".htm":
			  $icon = "htm.gif";
			  break;
		   case ".html":
			  $icon = "htm.gif";
			  break;
		   case ".jpeg":
			  $icon = "jpg.gif";
			  break;
		   case ".jpg":
			  $icon = "jpg.gif";
			  break;
		   case ".mov":
			  $icon = "mov.gif";
			  break;
		   case ".mpeg":
			  $icon = "mpg.gif";
			  break;
		   case ".mpg":
			  $icon = "mpg.gif";
			  break;
		   case ".mpx":
			  $icon = "mpx.gif";
			  break;
		   case ".p65":
			  $icon = "p65.gif";
			  break;
		   case ".pct":
			  $icon = "pct.gif";
			  break;
		   case ".pict":
			  $icon = "pct.gif";
			  break;
		   case ".pdf":
			  $icon = "pdf.gif";
			  break;
		   case ".png":
			  $icon = "png.gif";
			  break;
		   case ".ppt":
			  $icon = "ppt.gif";
			  break;
		   case ".ps":
			  $icon = "ps.gif";
			  break;
		   case ".psd":
			  $icon = "psd.gif";
			  break;
		   case ".pub":
			  $icon = "pub.gif";
			  break;
		   case ".rtf":
			  $icon = "rtf.gif";
			  break;
		   case ".sit":
			  $icon = "sit.gif";
			  break;
		   case ".swf":
			  $icon = "swf.gif";
			  break;
		   case ".ps":
			  $icon = "ps.gif";
			  break;
		   case ".tif":
			  $icon = "tif.gif";
			  break;
		   case ".tiff":
			  $icon = "tif.gif";
			  break;
		   case ".txt":
			  $icon = "txt.gif";
			  break;
		   case ".xls":
			  $icon = "xls.gif";
			  break;
		   case ".zip":
			  $icon = "zip.gif";
			  break;
		   case ".mif":
			  $icon = "mif.gif";
			  break;
		   case ".fm":
			  $icon = "fm.gif";
			  break;
		   case ".wpd":
			  $icon = "wpd.gif";
			  break;
		   case ".wp":
			  $icon = "wpd.gif";
			  break;
		   default:
			  $icon = "ukn.gif";
		  }
	   return $icon;
	   
	}
?>