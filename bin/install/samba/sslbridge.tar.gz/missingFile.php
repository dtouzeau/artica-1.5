<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>SSLBridge</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="./simple.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.wrap0, .wrap1, .wrap2, .wrap3 {
  display:inline-table;
  /* \*/display:block;/**/
  }
.wrap0 {
  float:left;
  background:url(images/shadow.gif) right bottom no-repeat;
  }
.wrap1 {
  background:url(images/shadow180.gif) no-repeat;
  }
.wrap2 {
  background:url(images/corner_bl.gif) -16px 100% no-repeat;
  }
.wrap3 {
  padding:4px 6px 6px 4px;
  background:url(images/corner_tr.gif) 100% -16px no-repeat;
  }
.box {
	padding: 10px;
	background: #FFFFF5;
	border: 1px solid;
	border-color:#ccc #999 #999 #ccc;
}
.texta {
 font-size: 14px;
 font-style: bold;
 color: #042696;
 background-color: #E7FFFF;
 border: 1px solid #666666;
}

h3 code {font-style:normal;}

.standardText{
	font-size:12pt;
	font-family: <?php echo FONT_FACE; ?>;
}

.errorText {
	color:#880000;
}

.noticeText{
	color:#555555;
}
-->
</style>
</head>
<body class="branded" >
<?php
	$unknownFile = false;
	$missingConfig = false;
	if(isset($_GET['f'])){
		$mfile = $_GET['f'];
		$mfile=htmlentities($mfile);
		if($mfile == 'config' || $mfile == 'config.php')
			$missingConfig = true;
		if(strlen($mfile)==0){
			$unknownFile = true;
			$mfile = '';
		}
	} else {
		$mfile = '';
		$unknownFile = true;
	}
//	echo strlen($mfile);

?>
<div id="masthead">Epiware SSLBridge</div> 
<div id="main">
			<div class="wrap0" style="width:500px;margin-left:auto;margin-right:auto;"> 
				<div class="wrap1"> 
					<div class="wrap2"> 
						<div class="wrap3"> 
							<div class="box" style="height:350px;"> 		
								<?php
									if($unknownFile){
										echo "<h2>File Missing</h2>";
										echo 'You are missing a critical file that is used with SSLBridge.  Please contact your 
											network administrator about this issue.<br />
											<br />
											<b>Administrator:</b> SSLBridge cannot determine which file is missing from this setup.
											It would be best to remove the current install of SSLBridge and replace it with a fresh
											installation.';
									} else if($missingConfig){
										echo "<h2>File Missing - $mfile</h2>";
										echo 'SSLBridge has not been properly configured to work yet.<br />
											<br />

											SSLBridge ships without a <font color=\'#990000\'><B>config.php</b></font> file.  
											<br /><br />

											The following install screens will help you 
											create this file.  We will try to write to the install directory first.  If we are unable to create this file 
											(ie.. do not have write privileges to install directory) the 
										    contents of the file will be generated and you will have to create this file in the installation directory.
											<br /><br /> 	 
                                             
											<b>Administrator:</b> 
												<BR><BR>
												

											 <input type=button value=\'  Start  Install  \' onClick=\'window.location.href="./ssl_install.php"\' >
										     Full installation . (recommded for new installations)

                                            <BR><BR>


  											Create only config.php file <a href="./setup1.php">CLICK HERE</a> ';


									} else if($mfile == 'json.php'){
										echo "<h2>File Missing - $mfile</h2>";
										echo 'You are the missing a critical file <i>'.$mfile.'</i> used with SSLBridge.  Please contact 		your network administrator about this issue.<br />
											<br />
											<b>Administrator:</b> SSLBridge determined that <i>'.$mfile.'</i> is missing from this setup.
											It may be sufficient to restore this file from a backup of SSLBridge.  If that does not resolve this issue, it would be best to remove the current install of SSLBridge and replace it with a fresh	installation.<br />
											<br />
											Alternativly, you could download the latest version of JSON from <a href="http://www.crockford.com/JSON/">http://www.crockford.com/JSON/</a>, although Epiware does not guarantee that SSLBridge will work with any other version of
											JSON other than the packaged version.';							
									} else if($mfile == 'Sajax.php') {
										echo "<h2>File Missing - $mfile</h2>";
										echo 'You are the missing a critical file <i>'.$mfile.'</i> used with SSLBridge.  Please contact 		your network administrator about this issue.<br />
											<br />
											<b>Administrator:</b> SSLBridge determined that <i>'.$mfile.'</i> is missing from this setup.
											It may be sufficient to restore this file from a backup of SSLBridge.  If that does not resolve this issue, it would be best to remove the current install of SSLBridge and replace it with a fresh	installation.<br />
											<br />
											Alternativly, you could download the latest version of SAJAX from <a href="http://www.modernmethod.com/sajax/">http://www.modernmethod.com/sajax/</a>, although Epiware does not guarantee that SSLBridge will work with any other version of
											SAJAX other than the packaged version.';				
									} else {
										echo "<h2>File Missing - $mfile</h2>";
										echo 'You are the missing a critical file <i>'.$mfile.'</i> used with SSLBridge.  Please 		contact your network administrator about this issue.<br />
											<br />
											<b>Administrator:</b> SSLBridge determined that <i>'.$mfile.'</i> is missing from this setup.
											It may be sufficient to restore this file from a backup of SSLBridge.  If that does not resolve this issue, it would be best to remove the current install of SSLBridge and replace it with a fresh	installation.';
									}
								?>
							</div> 
						</div> 
					</div> 
				</div> 
			</div>
</div>
</body>
</html>