<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
	require_once('./config.php');
	require_once('./corecfg.php');
	if(USESESSION == 'true'){
		$_SESSION['username'] = '';
		$_SESSION['password'] = '';
		session_destroy();
	} else {
		$set_time = -12000;
		setcookie("srvtm", $username,$set_time,CURRENT_DIR,"");
		setcookie("recversion", $password, $set_time,CURRENT_DIR,"");
	}

//print DEMOMODE;
//exit;
	if(DEMOMODE == 'true'){
		//exit;
		//print "Done";
		header("location: ../post_demo.php");
		exit;
	}
	header("location: ./index.php");
?>