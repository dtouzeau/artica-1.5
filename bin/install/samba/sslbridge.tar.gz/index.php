<?php
if(!@is_readable('./config.php')){
	header("location:./missingFile.php?f=config.php");
	exit;

} else if(!@is_readable('./corecfg.php')){
	header("location:./missingFile.php?f=smb_login_functions.php");
	exit;
} else if(!@is_readable('./smb_login_functions.php')){
	header("location:./missingFile.php?f=smb_login_functions.php");
	exit;
} else {
  require_once('./corecfg.php');
  require_once('./config.php');
  require_once('./smb_login_functions.php');
}
  require_once('./config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>SSLBridge For Artica</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="./simple.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.wrap0, .wrap1, .wrap2, .wrap3 {
  display:table;
  /* \*/display:block;/**/
  }
.wrap0 {
  float:left;
  background:url(images/shadow.gif) right bottom no-repeat;
  }
.wrap1 {
  background:url(images/shadow180.gif) no-repeat;
  }
.wrap2 {
  background:url(images/corner_bl.gif) -16px 100% no-repeat;
  }
.wrap3 {
  padding:4px 6px 6px 4px;
  background:url(images/corner_tr.gif) 100% -16px no-repeat;
  }
.box {
	padding: 10px;
	background: #FFFFF5;
	border: 1px solid;
	border-color:#ccc #999 #999 #ccc;
}
.texta {
 font-size: 14px;
 color: #042696;
 background-color: #E7FFFF;
 border: 1px solid #666666;
}

h3 code {font-style:normal;}

.standardText{
	font-size:12pt;
	font-family: <?php echo FONT_FACE; ?>;
}

.errorText {
	color:#880000;
}

.noticeText{
	color:#555555;
}
-->
</style>
<?php
	require_once('./smb_login_functions2.php');
?>

</head>
<body class="branded" onLoad="">

<div id="masthead"><a href="http://www.artica.fr" style="text-decoration:none">SSLBridge For Artica</a>  </div> 
<div style="float:right;font-size:.75em;"> 2006 <a href="http://www.epiware.com">Epiware</a>, All Rights Reserved
</div>
<?php print "<font size=-1 color=\"#777777\">version " . VERSION  . "</font>";  ?>
<?php
	display_login(400, 200, '25%', '25%');
?>
<div id="main">

</div>
</body>
</html>