<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>SSLBridge</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="./simple.css" rel="stylesheet" type="text/css" />
</head>
<body class="branded">
<div id="masthead">Epiware SSLBridge</div> 
<div id="main">
	<div class="wrap0" style="width:500px;margin-left:auto;margin-right:auto;"> 
		<div class="wrap1"> 
			<div class="wrap2"> 
				<div class="wrap3"> 
					<div class="box"> 		
						<h2>SSLBridge Installation</h2>
						<p>Thank you for running the SSLBridge installation.  This process consists of three parts:</p>
						<ol>	
							<li>Create the primary configuration file.</li>
							<li>Test system for possible errors.</li>

						</ol>
						<p>Press "Next" below to continue.</p>
						<p><form method="post" id="form1" name="form1" action="./setup1.php">
						   <input type="hidden" name="f" id="f" value="yes" />
							<input type="submit" value="     Next      ->" />
						   </form>
						</p>
					</div> 
				</div> 
			</div> 
		</div> 
	</div>
</div>
</body>
</html>