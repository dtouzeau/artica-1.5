<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>SSLBridge</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="./simple.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.wrap0, .wrap1, .wrap2, .wrap3 {
  display:inline-table;
  /* \*/display:block;/**/
  }
.wrap0 {
  float:left;
  background:url(images/shadow.gif) right bottom no-repeat;
  }
.wrap1 {
  background:url(images/shadow180.gif) no-repeat;
  }
.wrap2 {
  background:url(images/corner_bl.gif) -16px 100% no-repeat;
  }
.wrap3 {
  padding:4px 6px 6px 4px;
  background:url(images/corner_tr.gif) 100% -16px no-repeat;
  }
.box {
	padding: 10px;
	background: #FFFFF5;
	border: 1px solid;
	border-color:#ccc #999 #999 #ccc;
}
.texta {
 font-size: 14px;
 font-style: bold;
 color: #042696;
 background-color: #E7FFFF;
 border: 1px solid #666666;
}

h3 code {font-style:normal;}

.standardText{
	font-size:12pt;
	font-family: <?php echo FONT_FACE; ?>;
}

.errorText {
	color:#880000;
}

.noticeText{
	color:#555555;
}
-->
</style>

</head>
<body class="branded">
<?php
	if(isset($_POST['f'])){
		$f = $_POST['f'];
		if($f == 'install' || $f == 'yes')
			$install = "yes";
		else 
			$install = "no";
	} else {
		$install = "no";
	}
?>
<div id="masthead">Epiware SSLBridge</div> 
<div id="main">
	<div class="wrap0" style="width:500px;margin-left:auto;margin-right:auto;"> 
		<div class="wrap1"> 
			<div class="wrap2"> 
				<div class="wrap3"> 
							<div class="box" style="height:350px;"> 		
						<h2>Create SSLBridge Configuration File - Step 1</h2>
						<p>SSLBride will now ask you for a few settings in order to generate your configuration file.</p>
		



						    <p><form method="post" id="form1" name="form1" action="./setup2.php">
						   Enter name of Windows Domain Server. <BR> If you are unsure you may be able to use 'localhost'.<br />
						   <B>DO NOT USE A NUMERIC IP ADDRESS! </B><br>
						   <input type="text" name="localhostName" id="localhostName" value="localhost" /><br />
						   <br />
						   Path to temp directory. Directory where SSLBridge needs read/write access<br />
						   <input type="text" name="tmpName" id="tmpName" value="/tmp" /><br />	
						   <br />
						   <input type="hidden" name="f" id="f" value="<?php echo $install; ?>" />
						   <BR><BR><BR><BR><BR><BR>
						   <?php
								if($install=='yes'){
									echo '<input type="button" id="backBtn" onClick="javascript:window.location.href=\'ssl_install.php\'" value="<-   Previous   " />
										  <input type="submit" value="     Next   ->     " />';
								} else {
									echo '<input type="button" id="backBtn" onClick="javascript:window.location.href=\'index.php\'" value="<-   Previous   " />';
									echo '<input type="submit" value="     Next   ->     " />';
								}
						   ?>
						   </form>
						</p>
					</div> 
				</div> 
			</div> 
		</div> 
	</div>
</div>
</body>
</html>