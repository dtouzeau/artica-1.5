<?php
/******************************************************************************
SSLBRIDGE:Remotely access Network Neighborhood using just a browser.
http://www.epiware.com
Copyright (C) 2006 Patrick Waddingham

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

Epiware, Inc., hereby disclaims all copyright
interest in the program `SSLBridge' written
by Patrick Waddingham.

21 August 2006
James Kern, President of Epiware
*****************************************************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>SSLBridge</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="./simple.css" rel="stylesheet" type="text/css" />

<style type="text/css">
<!--
.wrap0, .wrap1, .wrap2, .wrap3 {
  display:inline-table;
  /* \*/display:block;/**/
  }
.wrap0 {
  float:left;
  background:url(images/shadow.gif) right bottom no-repeat;
  }
.wrap1 {
  background:url(images/shadow180.gif) no-repeat;
  }
.wrap2 {
  background:url(images/corner_bl.gif) -16px 100% no-repeat;
  }
.wrap3 {
  padding:4px 6px 6px 4px;
  background:url(images/corner_tr.gif) 100% -16px no-repeat;
  }
.box {
	padding: 10px;
	background: #FFFFF5;
	border: 1px solid;
	border-color:#ccc #999 #999 #ccc;
}
.texta {
 font-size: 14px;
 font-style: bold;
 color: #042696;
 background-color: #E7FFFF;
 border: 1px solid #666666;
}

h3 code {font-style:normal;}

.standardText{
	font-size:12pt;
	font-family: <?php echo FONT_FACE; ?>;
}

.errorText {
	color:#880000;
}

.noticeText{
	color:#555555;
}
-->
</style>

<style type="text/css">
	#leftBox{
		float:left;
		width:200px;
	}

	#rightBox{
		margin-left:201px;
		width:198px;
	}
</style>
<script type="text/javascript" src="x/x_core.js"></script>
<script type="text/javascript" src="x/x_dom.js"></script>
<script type="text/javascript" src="x/x_event.js"></script>
<script type="text/javascript">
	var listBox = null;
	var nameBox = null;
	var count = 0;

	function addItem(){
		addName(e);
		return false;
	}

	function addName(e){
		count++;
		var ourItem = document.createElement('option');
		ourItem.id = count;
		ourItem.value = count;

		var ourName = nameBox.value;
		if(ourName.indexOf("//") != 0){
			ourName = ourName.toUpperCase();
			while(ourName.indexOf(" ") > -1)
				ourName = ourName.replace(" ", "_");
		}

		var textDiv = document.createTextNode(ourName);
		ourItem.appendChild(textDiv);

		listBox.appendChild(ourItem);

	}

	function removeName(e){
		var ourID = listBox.value;
		listBox.removeChild(document.getElementById(ourID));
	}

	function processList(e){
		var theList = '';
		var arraySize = listBox.options.length;
		for(it = 0; it < arraySize; it++){
			theList = theList + listBox.options[it].innerHTML+'`';			
		}
		document.getElementById("z").value=theList;
		document.getElementById("form4").submit();
	}

	function init(e){
		listBox = document.getElementById("wglist");
		nameBox = document.getElementById("addName");

		xAddEventListener(document.getElementById("addBtn"),'click', addName, false);
		xAddEventListener(document.getElementById("rmvBtn"),'click', removeName, false);
		xAddEventListener(document.getElementById("makeFile"),'click', processList, false);
	}

	function backButton(loc){
		document.getElementById("form4").action = loc;
		document.getElementById("form4").submit();
	}

	xAddEventListener(window, 'load',init, false); 
</script>
</head>
<body class="branded">
<?php
	if(isset($_POST['f'])){
		$f = $_POST['f'];
		if($f == 'install' || $f == 'yes')
			$install = "yes";
		else 
			$install = "no";
	} else {
		$install = "no";
	}
?>
<div id="masthead">Epiware SSLBridge</div> 
<div id="main">
	<div class="wrap0" style="width:500px;margin-left:auto;margin-right:auto;"> 
		<div class="wrap1"> 
			<div class="wrap2"> 
				<div class="wrap3"> 
						<div class="box" style="height:350px;"> 
						<h2>Create Workgroup Exclusion List - Setp 1</h2>
						<p>Now SSLBridge will help you generate a list of workgroups that you do not want to appear in the application.  Sometimes workgroups can be seen that you do not want people to access, thus this exclusion list will be applied to the list of workgroups before being displayed to users.</p>
						<form id="form4" name="form4" method="post" action="./setup5.php" onsubmit="javascript:processList();">
						<input type="hidden" name="f" id="f" value="<?php echo $install; ?>" />
						<input type="hidden" name="z" id="z" value="" />
						<div id="leftBox">
							Workgroup Name: <input type="text" id="addName" name="addName" /><br />
							<input type="button" id="addBtn" value="Add >>" />
						</div>
						<div id="rightBox">
							<select name="wglist" id="wglist" size="5">
								<option id="0" value="0">//Add Names on from the Left</option>
							</select><br />
							<input type="button" id="rmvBtn" value="Remove" />
						</div>
						<?php
							if($install=='yes'){
								echo '<input type="button" id="backBtn" onClick="javascript:backButton(\'./setup3.php\')" value="<- Previous" />
									  <input type="button" id="makeFile" name="makeFile" value="Make File" />';
							} else {
								echo '<input type="button" id="makeFile" name="makeFile" value="Make File" />';
							}
						?>
						</form>
					</div> 
				</div> 
			</div> 
		</div> 
	</div>
</div>
</body>
</html>